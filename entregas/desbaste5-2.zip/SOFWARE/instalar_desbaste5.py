"""instalar_desbaste5.py — Desbaste de 5 ejes sin choques para la SD-M5 (tanda «desbaste5-1»).

Uso: copiar la carpeta SOFWARE de este zip encima de Documents\\SOFWARE y, desde Documents\\SOFWARE:
    venv\\Scripts\\python instalar_desbaste5.py
Hace respaldos *.bak-desbaste5 de todo lo que toca, cambia los archivos y parcha (por anclas) export/machin.js del
slicer y core/maquinasV2.js de Machin. Si un ancla no está, no toca ese archivo y lo dice.
Después: en BACKEND\\C+Desbaste  ->  ..\\..\\venv\\Scripts\\python -m pip install .   y reiniciar PMS.
"""
import glob, os, shutil, sys

RAIZ = os.path.dirname(os.path.abspath(__file__))
NUEVOS = os.path.join(RAIZ, "_desbaste5")
BAK = ".bak-desbaste5b"   # tanda 2 (la 1 dejó .bak-desbaste5)
MARCA = "desbaste de 5 ejes"


def respaldar(p):
    if os.path.exists(p) and not os.path.exists(p + BAK):
        shutil.copy2(p, p + BAK)


def copiar(rel):
    src, dst = os.path.join(NUEVOS, rel), os.path.join(RAIZ, rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    respaldar(dst)
    shutil.copy2(src, dst)
    print("  copiado", rel)


def buscar(rel):
    p = os.path.join(RAIZ, rel)
    if os.path.exists(p):
        return p
    nombre = os.path.basename(rel)
    hall = [h for h in glob.glob(os.path.join(RAIZ, "FRONTEND", "**", nombre), recursive=True) if ".bak" not in h]
    return hall[0] if len(hall) == 1 else None


def parchar(rel, cambios):
    p = buscar(rel)
    if not p:
        print("  NO ENCONTRADO", rel); return False
    s = open(p, encoding="utf-8").read()
    if MARCA in s:
        print("  ya estaba", os.path.relpath(p, RAIZ)); return True
    for a, b in cambios:
        if s.count(a) != 1:
            print("  ANCLA NO ENCONTRADA en", os.path.relpath(p, RAIZ), "->", a.strip()[:70]); return False
    for a, b in cambios:
        s = s.replace(a, b)
    respaldar(p)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("  parchado", os.path.relpath(p, RAIZ))
    return True


# ── slicer: pide primero el desbaste de 5 ejes (malla de la pieza) y guarda los vóxeles para la vista previa ──
SLICER = [
    ("let __fzCppOk = null;\n", """let __fzCppOk = null;
// desbaste de 5 ejes en C++ (/api/desbaste/fresado5): parte de la malla, desbasta desde arriba y desde los lados con A/C
// y mira la herramienta entera contra pieza, material, mesa, plato, garras, cuna y recorridos. Trae el material en vóxeles.
let __fz5Ok = null;
async function fresado5Backend(tris) {
    if (__fz5Ok === false || typeof fetch !== 'function' || !tris || !tris.length) return null;
    const f = tris instanceof Float32Array ? tris : Float32Array.from(tris), u8 = new Uint8Array(f.buffer, f.byteOffset, f.byteLength);
    let bin = '';
    for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    try {
        const r = await fetch('/api/desbaste/fresado5', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ tris: btoa(bin), opts: {} }) });
        if (r.status === 404 || r.status === 501) { __fz5Ok = false; log('Desbaste de 5 ejes no disponible (pip install . en BACKEND\\\\C+Desbaste y reiniciar PMS): sale el de 3 ejes.', 'warn'); return null; }
        const j = await r.json();
        if (!r.ok || !j.ok) { log('Desbaste de 5 ejes: ' + (j && j.error || r.status), 'err'); return r.status === 400 ? { error: true } : null; }
        const z = Uint8Array.from(atob(j.vox.q), (c) => c.charCodeAt(0));
        j.vox.q = new Uint16Array(await new Response(new Blob([z]).stream().pipeThrough(new DecompressionStream('deflate'))).arrayBuffer());
        return { text: j.scode, stats: j.stats, malla: null, vox: j.vox };
    } catch (e) { log('Desbaste de 5 ejes: ' + e.message, 'err'); return null; }
}
"""),
    ("    let res = await fresadoBackend(S.lastLayers, lh);\n",
     "    const r5 = await fresado5Backend(S.currentTriangles);\n    if (r5 && r5.error) { clearProgress(); return null; }   // la pieza no cabe: no sale un desbaste de 3 ejes en su lugar\n    let res = r5 || (await fresadoBackend(S.lastLayers, lh));\n"),
    ("    fresaCache = { layers: S.lastLayers, text: res.text, malla: res.malla || null };\n",
     """    if (res.vox) {
        const lados = (st.orientaciones || []).filter((o) => o.niveles).map((o) => (o.A ? `lado ${o.B}° (A ${o.A}°)` : 'arriba')).join(', ');
        log(`Desbaste de 5 ejes: ${lados || 'sin pasadas'}; ${st.niveles} capas con FRAME (A/C), choques evitados: ${st.choquesEvitados} puntos (fresa, portaherramientas, husillo, garras, cuna y recorridos), ` +
            `queda sin alcanzar el ${st.restante.toFixed(1)} % del material. Bloque apoyado en el plato (z ${st.zPieza} mm sobre la mesa).`, st.restante > 15 ? 'warn' : 'ok');
    }
    fresaCache = { layers: S.lastLayers, text: res.text, malla: res.malla || null, vox: res.vox || null };
"""),
    ("const psFresadoMalla = () =>", "const psFresadoVox = () => (fresaCache && fresaCache.layers === PS.state.lastLayers ? fresaCache.vox : null);\nconst psFresadoMalla = () =>"),
    ("psFresadoDe, psFresadoMalla });", "psFresadoDe, psFresadoMalla, psFresadoVox });"),
]

# ── Machin: en la SD-M5 la orientación de cada capa (A inclinación, B acimut) pasa a cuna A = A y mesa C = 90 - B ──
MACHIN = [
    ("    let ant = null, e = 0, capa0 = P.n ? P.layer[0] : 0;\n",
     "    let ant = null, e = 0, capa0 = P.n ? P.layer[0] : 0, cAnt = 0;\n"),
    ("        const p = { X: P.x[i] + dx, Y: P.y[i] + dy, Z: P.z[i], A, B, C: 0 };\n",
     """        let p = { X: P.x[i] + dx, Y: P.y[i] + dy, Z: P.z[i], A, B, C: 0 };
        // desbaste de 5 ejes en la SD-M5 (cuna A + mesa C): eje de la herramienta inclinado A hacia el acimut B = cuna A, mesa C = 90 - B (sin saltos de 360°)
        if (tipo === "cnc5_ac") { const c = A > 1e-6 ? 90 - B : cAnt, Cm = c + 360 * Math.round((cAnt - c) / 360); p = { X: p.X, Y: p.Y, Z: p.Z, A, B: 0, C: Cm }; cAnt = Cm; }
"""),
]

# instalaciones de la tanda 1: la pieza que no cabe ya no cae al desbaste de 3 ejes
ARREGLO1 = [
    ("""        if (!r.ok || !j.ok) { log('Desbaste de 5 ejes: ' + (j && j.error || r.status), 'err'); return null; }""",
     """        if (!r.ok || !j.ok) { log('Desbaste de 5 ejes: ' + (j && j.error || r.status), 'err'); return r.status === 400 ? { error: true } : null; }"""),
    ("    let res = (await fresado5Backend(S.currentTriangles)) || (await fresadoBackend(S.lastLayers, lh));\n",
     "    const r5 = await fresado5Backend(S.currentTriangles);\n    if (r5 && r5.error) { clearProgress(); return null; }   // la pieza no cabe: no sale un desbaste de 3 ejes en su lugar\n    let res = r5 || (await fresadoBackend(S.lastLayers, lh));\n"),
]


def arreglar(rel, cambios):
    p = buscar(rel)
    if not p:
        return
    s = open(p, encoding="utf-8").read()
    if all(a not in s for a, _ in cambios):
        return
    for a, b in cambios:
        if s.count(a) == 1:
            s = s.replace(a, b)
    respaldar(p)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("  actualizado", os.path.relpath(p, RAIZ))


print("Desbaste de 5 ejes (SD-M5):")
for rel in ["BACKEND/C+Desbaste/desbaste.cpp", "BACKEND/C+Desbaste/setup.py", "BACKEND/desbaste_api.py", "FRONTEND/motores/polarslicer/ui/desbaste.js"]:
    copiar(rel)
ok1 = parchar("FRONTEND/motores/polarslicer/export/machin.js", SLICER)
ok2 = parchar("FRONTEND/motores/machin/core/maquinasV2.js", MACHIN)
arreglar("FRONTEND/motores/polarslicer/export/machin.js", ARREGLO1)
print("Listo." if ok1 and ok2 else "Terminó con avisos (mira arriba).")
print("Ahora: cd BACKEND\\C+Desbaste  y  ..\\..\\venv\\Scripts\\python -m pip install .   y reiniciar PMS.")
