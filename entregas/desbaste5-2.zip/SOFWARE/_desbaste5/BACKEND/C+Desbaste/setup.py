# setup.py — compila el módulo «pms_desbaste» (desbaste de la SD-M5 en C++):  pip install .
import glob, os
from setuptools import setup
from pybind11.setup_helpers import Pybind11Extension, build_ext

C2 = os.path.join("clipper2", "CPP", "Clipper2Lib")
ext = Pybind11Extension(
    "pms_desbaste",
    ["desbaste.cpp"] + sorted(glob.glob(os.path.join(C2, "src", "clipper.*.cpp"))),
    include_dirs=[os.path.join(C2, "include")],
    cxx_std=17,
    define_macros=[("_USE_MATH_DEFINES", None)],   # M_PI en MSVC
    extra_compile_args=["/O2", "/utf-8"] if os.name == "nt" else ["-O3"],
)
setup(name="pms_desbaste", version="2.0", ext_modules=[ext], cmdclass={"build_ext": build_ext})
