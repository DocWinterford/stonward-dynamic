"""
BACKEND/desbaste_api.py — Desbaste de la SD-M5 en C++ (módulo «pms_desbaste», carpeta BACKEND/C+Desbaste).

POST /api/desbaste/fresado  {z, nlazos, npts, xy, layerH, opts}
  ->  {ok, scode, stats, malla: {x0, y0, px, nx, ny, z0, z1, zNivel, primero, ultimo}}   (primero/ultimo: uint16 en base64)
POST /api/desbaste/fresado5  {tris (float32 en base64, 9 por triángulo), opts}
  ->  {ok, scode, stats, vox: {x0, y0, z0, v, nx, ny, nz, q}}   (q: uint16 por vóxel, zlib + base64;
      0xFFFF pieza, 0 material que queda, k = quitado en la capa k)   desbaste de 5 ejes sin choques
Si el módulo no está compilado responde 501 y el slicer usa su versión JS.
"""
import base64
import logging
import zlib

from flask import Blueprint, jsonify, request

logger = logging.getLogger(__name__)

try:
    import pms_desbaste  # compilado con «pip install .» en BACKEND/C+Desbaste
except Exception:  # noqa: BLE001
    pms_desbaste = None


def crear_blueprint_desbaste():
    bp = Blueprint("desbaste", __name__)

    @bp.route("/api/desbaste/fresado", methods=["POST"])
    def _fresado():
        if pms_desbaste is None:
            return jsonify(ok=False, error="pms_desbaste no está compilado (pip install . en BACKEND/C+Desbaste)"), 501
        j = request.get_json(silent=True) or {}
        try:
            r = pms_desbaste.fresado(j.get("z") or [], j.get("nlazos") or [], j.get("npts") or [], j.get("xy") or [],
                                     float(j.get("layerH") or 0.2), j.get("opts") or {})
        except ValueError as e:
            return jsonify(ok=False, error=str(e)), 400
        except Exception as e:  # noqa: BLE001
            logger.exception("desbaste: fallo en el módulo C++")
            return jsonify(ok=False, error=str(e)), 500
        m = r["malla"]
        m["primero"] = base64.b64encode(m["primero"]).decode("ascii")
        m["ultimo"] = base64.b64encode(m["ultimo"]).decode("ascii")
        return jsonify(ok=True, scode=r["scode"].decode("utf-8"), stats=r["stats"], malla=m)

    @bp.route("/api/desbaste/fresado5", methods=["POST"])
    def _fresado5():
        if pms_desbaste is None or not hasattr(pms_desbaste, "fresado5"):
            return jsonify(ok=False, error="pms_desbaste sin fresado5 (pip install . en BACKEND/C+Desbaste y reiniciar PMS)"), 501
        j = request.get_json(silent=True) or {}
        try:
            tris = base64.b64decode(j.get("tris") or "")
            r = pms_desbaste.fresado5(tris, j.get("opts") or {})
        except ValueError as e:
            return jsonify(ok=False, error=str(e)), 400
        except Exception as e:  # noqa: BLE001
            logger.exception("desbaste 5 ejes: fallo en el módulo C++")
            return jsonify(ok=False, error=str(e)), 500
        v = r["vox"]
        v["q"] = base64.b64encode(zlib.compress(v["q"], 6)).decode("ascii")
        return jsonify(ok=True, scode=r["scode"].decode("utf-8"), stats=r["stats"], vox=v)

    return bp
