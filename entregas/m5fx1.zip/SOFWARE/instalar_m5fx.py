"""instalar_m5fx.py — SD-M5: garras que sí aprietan el bloque, fresa real que gira y refrigerante (tanda «m5fx1»).

Uso (con PMS cerrado), desde Documents\\SOFWARE:
    venv\\Scripts\\python instalar_m5fx.py
Copia desbaste.cpp (agarre de 12 mm + 4 garras en el cálculo de choques) y ui/desbaste.js del slicer, y parcha (por anclas)
motores/machin/core/maquinasV2.js. Respaldos *.bak-m5fx1. Después: pip install . en BACKEND\\C+Desbaste (dentro de vcvars64).
"""
import glob, os, shutil

RAIZ = os.path.dirname(os.path.abspath(__file__))
NUEVOS = os.path.join(RAIZ, "_desbaste5")
BAK = ".bak-m5fx1"


def respaldar(p):
    if os.path.exists(p) and not os.path.exists(p + BAK):
        shutil.copy2(p, p + BAK)


def buscar(rel):
    p = os.path.join(RAIZ, rel)
    if os.path.exists(p):
        return p
    hall = [h for h in glob.glob(os.path.join(RAIZ, "FRONTEND", "**", os.path.basename(rel)), recursive=True) if ".bak" not in h and "_desbaste5" not in h]
    return hall[0] if len(hall) == 1 else None


MARCA = "SD-M5 (cnc5_ac): fresa real que gira"
def aplicar(s, extras):
    if MARCA in s: return None
    C = [
        ("z0: +rw.STOCK_Z0 || 0, z1: +rw.STOCK_Z1, d: +rw.TOOL_DIAM || 6, filo: +rw.TOOL_STICKOUT || 0 } : null;",
         "z0: +rw.STOCK_Z0 || 0, z1: +rw.STOCK_Z1, d: +rw.TOOL_DIAM || 6, filo: +rw.TOOL_STICKOUT || 0,\n"
         "        flute: +rw.TOOL_FLUTE || 0, stick: +rw.TOOL_STICKOUT || 0, holder: +rw.HOLDER_DIAM || 0, grip: +rw.GRIP || 0, jawT: +rw.JAW_THICK || 0, jawW: +rw.JAW_WIDTH || 0,\n"
         "        jawZ0: rw.JAW_Z0 != null ? +rw.JAW_Z0 : null } : null;"),
        ("/* ── torno (SD-T2)", extras + "/* ── torno (SD-T2)"),
        ("    actualizarCables(P);\n    if (M.pant)", "    actualizarCables(P);\n    if (M.fresa) M.fresa.poner(P);\n    if (M.pant)"),
        ("    M.cables = crearCables(T, M.grupo, j.cables);\n", "    M.cables = crearCables(T, M.grupo, j.cables);\n    if (j.tipo === \"cnc5_ac\") { cnc5Ocultar(); crearFresa({}); }\n"),
        ("    if (prog.bloque) { M.bloque = crearBloque(prog.bloque); M.trazo.linea.visible = false; }\n",
         "    if (prog.bloque) { M.bloque = crearBloque(prog.bloque); M.trazo.linea.visible = false; }\n    if (prog.bloque && cnc5Es()) { crearFresa(prog.bloque); crearGarras(prog.bloque); }\n"),
        ("    if (!R.calentando) avanzar(dt * R.mult);\n    pintar(true);", "    if (!R.calentando) avanzar(dt * R.mult);\n    if (M.fresa) cnc5Cuadro(dt);\n    pintar(true);"),
        ("R.corriendo = !R.corriendo; R.ultimo = 0;", "R.corriendo = !R.corriendo; R.ultimo = 0; if (!R.corriendo && M.refri) M.refri(0, false);"),
        ("    R.corriendo = false; R.prog = null;\n    C.scene.remove(M.grupo);", "    R.corriendo = false; R.prog = null;\n    cnc5Quitar();\n    C.scene.remove(M.grupo);"),
        ("    C.scene.remove(t.grupo); t.g.dispose();", "    quitarGarras();\n    C.scene.remove(t.grupo); t.g.dispose();"),
    ]
    for a, b in C:
        if s.count(a) != 1: raise SystemExit("ANCLA NO ENCONTRADA en maquinasV2.js -> " + a.strip()[:70])
    for a, b in C: s = s.replace(a, b)
    return s

print("SD-M5 garras, fresa y refrigerante:")
for rel in ["BACKEND/C+Desbaste/desbaste.cpp", "FRONTEND/motores/polarslicer/ui/desbaste.js"]:
    dst = os.path.join(RAIZ, rel); respaldar(dst); shutil.copy2(os.path.join(NUEVOS, rel), dst); print("  copiado", rel)
p = buscar("FRONTEND/motores/machin/core/maquinasV2.js")
if not p:
    print("  NO ENCONTRADO maquinasV2.js")
else:
    s = open(p, encoding="utf-8").read()
    n = aplicar(s, open(os.path.join(NUEVOS, "m5fx_extras.js"), encoding="utf-8").read())
    if n is None:
        print("  ya estaba", os.path.relpath(p, RAIZ))
    else:
        respaldar(p); open(p, "w", encoding="utf-8", newline="\n").write(n); print("  parchado", os.path.relpath(p, RAIZ))
    print("Listo.")
print("Ahora: cd BACKEND\\C+Desbaste  y  ..\\..\\venv\\Scripts\\python -m pip install .   (dentro de vcvars64) y reiniciar PMS.")
