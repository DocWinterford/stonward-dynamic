/* ── SD-M5 (cnc5_ac): fresa real que gira, garras que aprietan el bloque y refrigerante ──────────────────
   La fresa (punta en el origen, eje +z del eslabón de la herramienta): 4 filos helicoidales de metal duro recubierto,
   mango pulido, tuerca ER y portaherramientas hasta el cono HSK del modelo. Las garras van en el marco de trabajo,
   una por cara del bloque, y se cierran sobre el agarre al cargar el programa. El refrigerante sale de 2 boquillas
   articuladas del husillo hacia la punta mientras la máquina corre (gotas con gravedad que salpican en el material). */
const FX = { rps: 2.2, gotas: 1400, chorro: 900 };
function cnc5Es() { return M && M.j.tipo === "cnc5_ac"; }
// piezas de adorno del modelo que ahora hace MACHIN de verdad (la barra de torneado, las 3 garras fijas y la pieza Ø60)
// (y las 3 mangueras lisas de refrigerante del modelo: ahora las boquillas son las de la fresa, que sí echan líquido)
function cnc5Ocultar() {
    M.mallas.forEach(({ mesh, def }) => { if (/^(mesa_garras|mesa_t_|mesa_pieza|herramienta)/.test(def.id || "")) mesh.visible = false; });
    (M.cables || []).forEach(({ mesh, def }) => { if (/^refrigerante/.test(def.id || "")) mesh.visible = false; });
}
function geoFilos(T, R, Lf) {
    const nf = R >= 2.5 ? 4 : 3, N = 24 * nf, hel = Math.tan(30 * Math.PI / 180) / R, paso = Math.max(0.2, Math.min(0.6, Lf / 70));
    const nz = Math.ceil(Lf / paso) + 1, sal = Math.min(2.5, Lf * 0.15);   // al final los filos se abren hacia el mango
    const perfil = (th) => {   // filo vivo en R, faja con alivio y la garganta hasta el alma (0.62 R)
        const f = ((th * nf) / (2 * Math.PI)) % 1;
        return f < 0.42 ? R * (1 - 0.05 * f / 0.42) : R * (0.95 - 0.33 * Math.sin(Math.PI * (f - 0.42) / 0.58));
    };
    const pos = [], idx = [];
    for (let k = 0; k < nz; k++) {
        const z = Math.min(Lf, k * paso), giro = z * hel, abre = Math.max(0, (z - (Lf - sal)) / sal);
        for (let i = 0; i < N; i++) {
            const th = (i / N) * 2 * Math.PI, r = perfil(th) * (1 - abre) + R * 0.985 * abre;
            pos.push(r * Math.cos(th + giro), r * Math.sin(th + giro), z);
        }
    }
    for (let k = 0; k + 1 < nz; k++) for (let i = 0; i < N; i++) {
        const a = k * N + i, b = k * N + ((i + 1) % N), c = b + N, d = a + N;
        idx.push(a, b, c, a, c, d);
    }
    const cen = pos.length / 3; pos.push(0, 0, 0.12);   // punta plana con un poco de cóncavo en el centro
    for (let i = 0; i < N; i++) idx.push(cen, (i + 1) % N, i);
    const g = new T.BufferGeometry();
    g.setAttribute("position", new T.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals();
    return g;
}
function cilZ(T, r0, r1, z0, z1, n) { const g = new T.CylinderGeometry(r1, r0, z1 - z0, n || 40); g.rotateX(Math.PI / 2); g.translate(0, 0, (z0 + z1) / 2); return g; }
function crearFresa(f) {
    const T = C.THREE, h = M.j.herramienta || {};
    if (M.fresa) { M.grupo.remove(M.fresa.grupo); M.fresa.grupo.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); }); }
    const D = f.d || 6, R = D / 2, Lf = Math.max(D, f.flute || 3 * D), Ls = Math.max(Lf + 2, f.stick || 40), Rh = (f.holder || 35) / 2;
    const cono = Math.max(Ls + 14, ((M.params.cnc5 && M.params.cnc5.herramienta) || 120) - 60);   // donde empieza el cono HSK del modelo
    const mat = (c, m, r) => { const x = new T.MeshStandardMaterial({ color: new T.Color(c), metalness: m, roughness: r }); x.envMapIntensity = 0.8; return x; };
    const giro = new T.Group(), grupo = new T.Group();
    grupo.matrixAutoUpdate = false; grupo.name = "Fresa"; grupo.userData.v2 = true;
    const add = (g, m, nombre, gira) => { const x = new T.Mesh(g, m); x.castShadow = true; x.receiveShadow = true; x.name = nombre; x.userData.v2 = true; (gira ? giro : grupo).add(x); return x; };
    add(geoFilos(T, R, Lf), mat("#596069", 0.9, 0.24), `Fresa plana Ø${D} de metal duro, 4 filos helicoidales 30°`, true);
    add(cilZ(T, R * 0.985, R, Lf, Ls, 40), mat("#c9ced3", 0.97, 0.12), "Mango h6", true);
    // marca láser en el mango (se ve girar)
    add(new T.BoxGeometry(R * 0.5, 0.15, Math.min(6, (Ls - Lf) * 0.5)).translate(0, R + 0.02, Lf + (Ls - Lf) * 0.55), mat("#2a2d31", 0.3, 0.6), "Marca del mango", true);
    // tuerca ER con ranuras y cuerpo del portaherramientas hasta el cono
    const nut = add(cilZ(T, Rh * 0.78, Rh * 0.88, Ls, Ls + 12, 48), mat("#a9b0b7", 0.92, 0.25), "Tuerca ER", true);
    for (let k = 0; k < 6; k++) { const r = new T.Mesh(new T.BoxGeometry(3, 2.2, 7), mat("#5d636a", 0.8, 0.4)); const a = k * Math.PI / 3; r.position.set(Math.cos(a) * Rh * 0.86, Math.sin(a) * Rh * 0.86, Ls + 6); r.rotation.z = a; r.userData.v2 = true; nut.add(r); }
    add(cilZ(T, Rh * 0.9, Rh, Ls + 12, cono, 48), mat("#c9ced3", 0.97, 0.16), "Portaherramientas", true);
    grupo.add(giro);
    // boquillas de refrigerante (no giran): mangueras articuladas desde la nariz del husillo hacia la punta
    const boq = [];
    [90, 210, 330].forEach((ang) => {
        const a = ang * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a), Rn = 44;
        const ini = new T.Vector3(Rn * ca, Rn * sa, cono + 64), fin = new T.Vector3((R + 16) * ca, (R + 16) * sa, Lf + 22);
        const curva = new T.CatmullRomCurve3([ini, new T.Vector3(Rn * ca * 1.1, Rn * sa * 1.1, cono + 30), new T.Vector3((R + 30) * ca, (R + 30) * sa, Lf + 48), fin]);
        const n = 22;
        for (let k = 0; k <= n; k++) {   // eslabones tipo Loc-Line: esferas encadenadas
            const p = curva.getPoint(k / n), s = new T.Mesh(new T.SphereGeometry(3.4, 14, 10), mat(k % 2 ? "#2f6fd1" : "#3a7be0", 0.1, 0.45));
            s.position.copy(p); s.scale.set(1, 1, 0.8); s.userData.v2 = true; s.castShadow = true; grupo.add(s);
        }
        const objetivo = new T.Vector3(0, 0, Math.min(6, Lf * 0.3)), dir = objetivo.clone().sub(fin).normalize();
        const tob = new T.Mesh(new T.CylinderGeometry(1.1, 2.6, 9, 16), mat("#e0703a", 0.2, 0.4));
        tob.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), dir); tob.position.copy(fin).addScaledVector(dir, 4.5); tob.userData.v2 = true; grupo.add(tob);
        boq.push({ p: fin.clone().addScaledVector(dir, 9), d: dir });
    });
    M.grupo.add(grupo);
    M.fresa = { grupo, giro, boq, ang: 0, base: new T.Matrix4(), D, R, Lf, h };
    M.fresa.poner = (P) => {
        const F = M.fresa, p = (F.h.punta || [0, 0, 0]);
        F.base.copy(P[F.h.eslabon] || new T.Matrix4()).multiply(new T.Matrix4().makeTranslation(p[0], p[1], p[2]));
        F.grupo.matrix.copy(F.base); F.grupo.matrixWorldNeedsUpdate = true;
    };
    M.fresa.poner(poses());
    if (!M.refri) M.refri = crearRefri(T);
}
// garras: 4, una por cara del bloque, aprietan el agarre (las mismas que usa el cálculo de choques del C++)
function crearGarras(b) {
    const T = C.THREE;
    quitarGarras();
    const g = b.grip || 0, z0 = b.jawZ0 != null ? b.jawZ0 : b.z0 - 6, z1 = b.z0 + Math.max(g, 8), Gr = b.jawT || 22, An = b.jawW || 26;
    const cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, alto = z1 - z0;
    const mat = new T.MeshStandardMaterial({ color: new T.Color("#2b2d31"), metalness: 0.75, roughness: 0.4 }); mat.envMapIntensity = 0.4;
    const matCara = new T.MeshStandardMaterial({ color: new T.Color("#8d949b"), metalness: 0.9, roughness: 0.35 });
    const lados = [{ c: [b.x1, cy], n: [1, 0] }, { c: [b.x0, cy], n: [-1, 0] }, { c: [cx, b.y1], n: [0, 1] }, { c: [cx, b.y0], n: [0, -1] }];
    const lista = lados.map((L) => {
        const q = new T.Group(); q.userData.v2 = true; q.name = "Garra";
        const cuerpo = new T.Mesh(new T.BoxGeometry(Gr, An, alto), mat); cuerpo.position.set(Gr / 2, 0, alto / 2);
        const pie = new T.Mesh(new T.BoxGeometry(Gr + 14, An, 6), mat); pie.position.set(Gr / 2 + 7, 0, 3);   // escalón que corre en la ranura del plato
        const cara = new T.Mesh(new T.BoxGeometry(0.8, An - 2, alto - 6), matCara); cara.position.set(0.4, 0, alto / 2 + 2);   // cara estriada que muerde
        const tor = new T.Mesh(cilZ(T, 4.2, 4.2, alto, alto + 1.5, 20), matCara); tor.position.set(Gr * 0.6, 0, 0);
        [cuerpo, pie, cara, tor].forEach((m) => { m.castShadow = true; m.receiveShadow = true; m.userData.v2 = true; q.add(m); });
        q.rotation.z = Math.atan2(L.n[1], L.n[0]);
        M.trazo.grupo.add(q);
        return { q, L, z0 };
    });
    M.garras = { lista, t0: performance.now(), abierto: 30 };
    const anim = (ts) => {
        if (!M || !M.garras || M.garras.lista !== lista) return;
        const t = Math.min(1, (performance.now() - M.garras.t0) / 900), e = 1 - (1 - t) ** 3, ab = M.garras.abierto * (1 - e);
        lista.forEach(({ q, L }) => { q.position.set(L.c[0] + L.n[0] * ab, L.c[1] + L.n[1] * ab, z0); });
        C.markActive && C.markActive();
        if (t < 1) requestAnimationFrame(anim); else C.toast("Garras cerradas: el bloque queda apretado por el agarre.", "info");
    };
    requestAnimationFrame(anim);
}
function quitarGarras() {
    if (!M || !M.garras) return;
    M.garras.lista.forEach(({ q }) => { if (q.parent) q.parent.remove(q); q.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); });
    M.garras = null;
}
// refrigerante: gotas en el mundo (z arriba), salen de las boquillas hacia la punta, caen y salpican en el material
function crearRefri(T) {
    const N = FX.gotas, pos = new Float32Array(N * 3).fill(1e6), vel = new Float32Array(N * 3), vida = new Float32Array(N);
    const geo = new T.BufferGeometry(); geo.setAttribute("position", new T.BufferAttribute(pos, 3));
    const mat = new T.PointsMaterial({ color: 0x9fd8ff, size: 1.6, transparent: true, opacity: 0.6, depthWrite: false, sizeAttenuation: true });
    const pts = new T.Points(geo, mat); pts.frustumCulled = false; pts.name = "Refrigerante"; pts.userData.v2 = true; pts.renderOrder = 4;
    C.scene.add(pts);
    let sig = 0, vivas = 0;
    const inv = new T.Matrix4(), w = new T.Vector3(), tipW = new T.Vector3();
    const fn = (dt, activo) => {
        const F = M.fresa; if (!F) return;
        if (!activo) { if (vivas) { pos.fill(1e6); vida.fill(0); vivas = 0; geo.attributes.position.needsUpdate = true; } return; }
        {
            F.grupo.updateMatrixWorld(true);
            tipW.set(0, 0, 0).applyMatrix4(F.grupo.matrixWorld);
            F.boq.forEach((b) => {
                const p = b.p.clone().applyMatrix4(F.grupo.matrixWorld), d = b.d.clone().transformDirection(F.grupo.matrixWorld);
                const nuevas = Math.min(N / 4, Math.ceil(dt * FX.chorro));
                for (let m = 0; m < nuevas; m++) {
                    const k = sig; sig = (sig + 1) % N; const o = k * 3, v = 1100 + Math.random() * 250, j = 45;
                    pos[o] = p.x; pos[o + 1] = p.y; pos[o + 2] = p.z;
                    vel[o] = d.x * v + (Math.random() - 0.5) * j; vel[o + 1] = d.y * v + (Math.random() - 0.5) * j; vel[o + 2] = d.z * v + (Math.random() - 0.5) * j;
                    vida[k] = 0.35 + Math.random() * 0.4;
                }
            });
        }
        const B = M.bloque && M.bloque.tipo === "bloque" ? M.bloque : null;
        if (M.trazo) { M.trazo.grupo.updateMatrixWorld(true); inv.copy(M.trazo.grupo.matrixWorld).invert(); }
        vivas = 0;
        for (let k = 0; k < N; k++) {
            if (vida[k] <= 0) continue;
            const o = k * 3; vida[k] -= dt;
            if (vida[k] <= 0) { pos[o] = pos[o + 1] = pos[o + 2] = 1e6; continue; }
            vivas++;
            vel[o + 2] -= 9800 * dt;
            pos[o] += vel[o] * dt; pos[o + 1] += vel[o + 1] * dt; pos[o + 2] += vel[o + 2] * dt;
            // pega en la fresa: se abre en abanico alrededor de la punta
            const dx = pos[o] - tipW.x, dy = pos[o + 1] - tipW.y, dz = pos[o + 2] - tipW.z;
            if (dx * dx + dy * dy < (F.R + 1) ** 2 && dz > -1 && dz < F.Lf) {
                const a = Math.random() * 2 * Math.PI, v = 250 + Math.random() * 300;
                vel[o] = Math.cos(a) * v; vel[o + 1] = Math.sin(a) * v; vel[o + 2] = 60 + Math.random() * 180; vida[k] = Math.min(vida[k], 0.3);
            }
            if (M.trazo) w.set(pos[o], pos[o + 1], pos[o + 2]).applyMatrix4(inv);
            if (M.trazo && w.z < 0) { vida[k] = 0; pos[o] = pos[o + 1] = pos[o + 2] = 1e6; continue; }   // llegó a la mesa
            if (B) {   // sobre el material: salpica y se escurre
                const ix = Math.round((w.x - B.f.x0) / B.px), iy = Math.round((w.y - B.f.y0) / B.py);
                if (ix >= 0 && iy >= 0 && ix <= B.nx && iy <= B.ny && w.z < B.h[iy * (B.nx + 1) + ix] && w.z > B.f.z0 - 2) {
                    const a = Math.random() * 2 * Math.PI, v = 40 + Math.random() * 90;
                    vel[o] = Math.cos(a) * v; vel[o + 1] = Math.sin(a) * v; vel[o + 2] = 30 + Math.random() * 60; vida[k] = Math.min(vida[k], 0.18);
                }
            }
        }
        geo.attributes.position.needsUpdate = true;
    };
    fn.quitar = () => { C.scene.remove(pts); geo.dispose(); mat.dispose(); };
    return fn;
}
// cada cuadro: la fresa gira (si la máquina corre) y el refrigerante cae
function cnc5Cuadro(dt) {
    const F = M && M.fresa; if (!F) return;
    const corre = R.corriendo && R.prog && R.i < R.prog.movs.length;
    if (corre) { F.ang = (F.ang + dt * FX.rps * 2 * Math.PI) % (2 * Math.PI); F.giro.rotation.z = F.ang; }
    if (M.refri) M.refri(dt, corre && !!M.bloque);
}
function cnc5Quitar() {
    if (!M) return;
    quitarGarras();
    if (M.refri) { M.refri.quitar(); M.refri = null; }
    if (M.fresa) { M.grupo.remove(M.fresa.grupo); M.fresa.grupo.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); }); M.fresa = null; }
}
