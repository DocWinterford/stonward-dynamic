/* ui/desbaste.js — Vista previa del desbaste de la SD-M5 en el slicer: con la 5 ejes elegida, en lugar de la pieza
   impresa se ve el bloque de material y cómo lo va comiendo la fresa. El deslizador de capas recorre los niveles del
   desbaste (de arriba hacia abajo); al final queda la pieza con su sobrematerial.
   El bloque es un mapa de alturas: por celda, el primer y el último nivel que la fresa toca (la altura tras el nivel L
   es la del último nivel ≤ L que la tocó). Lo calcula el C++ (BACKEND/C+Desbaste); si no está, se saca aquí del S-code
   de cinematica/fresado.js. Este archivo solo pinta. Script clásico: cuelga de window.PolarSlicer.
   Con el desbaste de 5 ejes (C++ fresado5) el bloque viene en vóxeles con la capa en que se quitó cada uno: se ve
   tallado también desde los lados (en gris lo que queda, en azul la pieza). */
(function () {
const PS = window.PolarSlicer;
const S = PS.state;
const { THREE, scene, __psById, log } = PS;
const MAX_CELDAS = 60000;

let V = null; // { layers, mesh, nx, ny, z1, prim, ult (Uint16 por celda), zNivel, nNiv, nivel } o { layers, mesh, vox, nNiv, nivel }

// ── bloque en vóxeles (5 ejes): caras entre lo sólido y lo vacío tras el nivel dado ──
function geomVox(X, nivel) {
    const { nx, ny, nz, v, x0, y0, q } = X, z0 = X.z0 - (X.zPieza || 0);   // el slicer tiene la pieza en z = 0
    const sol = (i, j, k) => { if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) return 0; const c = q[(k * ny + j) * nx + i]; return c === 0xFFFF ? (k < (X.kAgarre || 0) ? 1 : 2) : c === 0 || c > nivel ? 1 : 0; };   // el agarre (debajo de la pieza) se ve como material
    let cap = 1 << 16, n = 0, pos = new Float32Array(cap * 12), nor = new Float32Array(cap * 12), col = new Float32Array(cap * 12);
    const crecer = () => { cap *= 2; const g = (a) => { const b = new Float32Array(cap * 12); b.set(a); return b; }; pos = g(pos); nor = g(nor); col = g(col); };
    const gris = [0.62, 0.65, 0.68], azul = [0.36, 0.62, 0.86];
    // cara: eje d (0 x, 1 y, 2 z), sentido s, esquina (i, j, k) del vóxel
    const cara = (i, j, k, d, sg, c) => {
        if (n === cap) crecer();
        const X0 = x0 + i * v, Y0 = y0 + j * v, Z0 = z0 + k * v, o = n * 12;
        let q4;
        if (d === 0) { const xx = sg > 0 ? 1 : 0; q4 = sg > 0 ? [[xx, 0, 0], [xx, 1, 0], [xx, 1, 1], [xx, 0, 1]] : [[xx, 0, 0], [xx, 0, 1], [xx, 1, 1], [xx, 1, 0]]; }
        else if (d === 1) { const yy = sg > 0 ? 1 : 0; q4 = sg > 0 ? [[0, yy, 0], [0, yy, 1], [1, yy, 1], [1, yy, 0]] : [[0, yy, 0], [1, yy, 0], [1, yy, 1], [0, yy, 1]]; }
        else { const zz = sg > 0 ? 1 : 0; q4 = sg > 0 ? [[0, 0, zz], [1, 0, zz], [1, 1, zz], [0, 1, zz]] : [[0, 0, zz], [0, 1, zz], [1, 1, zz], [1, 0, zz]]; }
        const nn = [d === 0 ? sg : 0, d === 1 ? sg : 0, d === 2 ? sg : 0], cc = c === 2 ? azul : gris;
        for (let t = 0; t < 4; t++) {
            pos[o + 3 * t] = X0 + q4[t][0] * v; pos[o + 3 * t + 1] = Y0 + q4[t][1] * v; pos[o + 3 * t + 2] = Z0 + q4[t][2] * v;
            nor[o + 3 * t] = nn[0]; nor[o + 3 * t + 1] = nn[1]; nor[o + 3 * t + 2] = nn[2];
            col[o + 3 * t] = cc[0]; col[o + 3 * t + 1] = cc[1]; col[o + 3 * t + 2] = cc[2];
        }
        n++;
    };
    for (let k = 0; k < nz; k++) for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
        const c = sol(i, j, k); if (!c) continue;
        if (!sol(i - 1, j, k)) cara(i, j, k, 0, -1, c); if (!sol(i + 1, j, k)) cara(i, j, k, 0, 1, c);
        if (!sol(i, j - 1, k)) cara(i, j, k, 1, -1, c); if (!sol(i, j + 1, k)) cara(i, j, k, 1, 1, c);
        if (!sol(i, j, k - 1)) cara(i, j, k, 2, -1, c); if (!sol(i, j, k + 1)) cara(i, j, k, 2, 1, c);
    }
    const idx = new Uint32Array(n * 6);
    for (let f = 0; f < n; f++) { const a = 4 * f, o = 6 * f; idx[o] = a; idx[o + 1] = a + 1; idx[o + 2] = a + 2; idx[o + 3] = a; idx[o + 4] = a + 2; idx[o + 5] = a + 3; }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos.subarray(0, n * 12), 3));
    g.setAttribute('normal', new THREE.BufferAttribute(nor.subarray(0, n * 12), 3));
    g.setAttribute('color', new THREE.BufferAttribute(col.subarray(0, n * 12), 3));
    g.setIndex(new THREE.BufferAttribute(idx, 1));
    return g;
}

function quitar() {
    if (!V) return;
    scene.remove(V.mesh); V.mesh.geometry.dispose(); V.mesh.material.dispose();
    V = null;
    applyVis(); // la pieza impresa vuelve
}

// Bloque: del C++ si lo trae, si no del S-code (primer / último nivel que toca cada celda)
function calcular(text) {
    const m = PS.psFresadoMalla && PS.psFresadoMalla();
    if (m) return { b: { x0: m.x0, x1: m.x1, y0: m.y0, y1: m.y1, z0: m.z0, z1: m.z1 }, px: m.px, nx: m.nx, ny: m.ny, prim: m.primero, ult: m.ultimo, zNivel: m.zNivel, cpp: true };
    const ex = PS.expandScode(text, { seg: 1, tipOnTop: false }), P = ex.path, raw = ex.header.raw;
    const b = { x0: +raw.STOCK_X0, x1: +raw.STOCK_X1, y0: +raw.STOCK_Y0, y1: +raw.STOCK_Y1, z0: +raw.STOCK_Z0 || 0, z1: +raw.STOCK_Z1 };
    const r = (+raw.TOOL_DIAM || 6) / 2, ap = +raw.LAYER_STEP || 1, nNiv = Math.max(1, Math.round((b.z1 - b.z0) / ap));
    const px = Math.max(0.25, Math.sqrt(((b.x1 - b.x0) * (b.y1 - b.y0)) / MAX_CELDAS));
    const nx = Math.max(2, Math.ceil((b.x1 - b.x0) / px) + 1), ny = Math.max(2, Math.ceil((b.y1 - b.y0) / px) + 1);
    const prim = new Uint16Array(nx * ny), ult = new Uint16Array(nx * ny), rc = Math.ceil(r / px), r2 = r * r;
    const zNivel = []; for (let k = 0; k <= nNiv; k++) zNivel.push(b.z1 - ap * k);
    for (const L of ex.layers) {
        const k = L.index + 1;
        for (let i = Math.max(L.i0, 1); i < L.i1; i++) {
            if (!P.e[i]) continue;
            const x = P.x[i], y = P.y[i];
            const ci = Math.round((x - b.x0) / px), cj = Math.round((y - b.y0) / px);
            for (let dj = -rc; dj <= rc; dj++) {
                const j = cj + dj; if (j < 0 || j >= ny) continue;
                const yy = b.y0 + j * px - y;
                for (let di = -rc; di <= rc; di++) {
                    const q = ci + di; if (q < 0 || q >= nx) continue;
                    const xx = b.x0 + q * px - x;
                    if (xx * xx + yy * yy <= r2) { const o = j * nx + q; if (!prim[o]) prim[o] = k; ult[o] = k; }
                }
            }
        }
    }
    return { b, px, nx, ny, prim, ult, zNivel, cpp: false };
}

// Malla: tapa (mapa de alturas) + cuatro paredes hasta el fondo del bloque
function malla(c) {
    const { b, px, nx, ny } = c, nt = nx * ny, nb = 2 * (nx + ny - 2);
    const pos = new Float32Array(3 * (nt + nb)), idx = [];
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { const o = 3 * (j * nx + i); pos[o] = b.x0 + Math.min(i * px, b.x1 - b.x0); pos[o + 1] = b.y0 + Math.min(j * px, b.y1 - b.y0); pos[o + 2] = b.z1; }
    for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) { const a = j * nx + i; idx.push(a, a + 1, a + nx, a + 1, a + nx + 1, a + nx); }
    // borde de la tapa en orden, con su copia abajo
    const borde = [];
    for (let i = 0; i < nx; i++) borde.push(i);
    for (let j = 1; j < ny; j++) borde.push(j * nx + nx - 1);
    for (let i = nx - 2; i >= 0; i--) borde.push((ny - 1) * nx + i);
    for (let j = ny - 2; j > 0; j--) borde.push(j * nx);
    borde.forEach((t, k) => { const o = 3 * (nt + k); pos[o] = pos[3 * t]; pos[o + 1] = pos[3 * t + 1]; pos[o + 2] = b.z0; });
    for (let k = 0; k < borde.length; k++) {
        const a = borde[k], c2 = borde[(k + 1) % borde.length], A = nt + k, B = nt + (k + 1) % borde.length;
        idx.push(a, A, c2, c2, A, B);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setIndex(idx);
    const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: 0x9aa3ab, roughness: 0.5, metalness: 0.15, side: THREE.DoubleSide }));
    m.name = 'ps-desbaste';
    return m;
}

function mostrarNivel(nivel) {
    if (!V) return;
    if (V.vox) { const g = geomVox(V.vox, nivel); V.mesh.geometry.dispose(); V.mesh.geometry = g; V.nivel = nivel; return; }
    const a = V.mesh.geometry.attributes.position, P = V.prim, U = V.ult, Z = V.zNivel;
    for (let o = 0; o < V.nx * V.ny; o++) a.array[3 * o + 2] = P[o] && nivel >= P[o] ? Z[Math.min(nivel, U[o])] : V.z1;
    a.needsUpdate = true;
    V.mesh.geometry.computeVertexNormals();
    V.nivel = nivel;
}

// deslizador de capas → nivel del desbaste (la última capa = desbaste terminado)
function applyCapa() {
    const sl = __psById('layerSlider');
    if (!V) return;
    if (S.lastLayers !== V.layers) { quitar(); return; }
    if (S.simLayerGroups) for (const [, g] of S.simLayerGroups) g.visible = false;
    const n = Math.max(1, S.lastLayers.length), idx = sl ? parseInt(sl.value) || 0 : n - 1;
    const nivel = Math.round(((idx + 1) / n) * V.nNiv);
    if (nivel !== V.nivel) mostrarNivel(nivel);
    const info = __psById('layerInfo');
    const txt = `Desbaste: nivel ${nivel} de ${V.nNiv}`;
    if (info && info.textContent !== txt) info.textContent = txt;   // el observador de abajo vuelve a entrar y ya no cambia nada
}

async function psVistaDesbaste() {
    const fresa = PS.psMaquina && PS.psMaquina().fresa;
    if (!fresa || !S.lastLayers) { quitar(); return; }
    if (V && V.layers === S.lastLayers) { applyCapa(); return; }
    if (V) quitar();
    const text = await PS.psFresadoDe();
    if (!text) return;
    const t0 = performance.now();
    const X = PS.psFresadoVox && PS.psFresadoVox();
    if (X) {
        const nNiv = X.niveles || 1;
        const mesh = new THREE.Mesh(geomVox(X, nNiv), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.5, metalness: 0.15 }));
        mesh.name = 'ps-desbaste';
        scene.add(mesh);
        V = { layers: S.lastLayers, mesh, vox: X, nNiv, nivel: nNiv };
        applyCapa();
        log(`Vista previa del desbaste de 5 ejes: ${X.nx} × ${X.ny} × ${X.nz} vóxeles de ${X.v.toFixed(2)} mm, ${nNiv} capas (${((performance.now() - t0) / 1000).toFixed(1)} s). El deslizador de capas recorre el desbaste.`, 'ok');
        return;
    }
    let c;
    try { c = calcular(text); } catch (err) { log('Vista previa del desbaste: ' + err.message, 'err'); return; }
    const mesh = malla(c);
    scene.add(mesh);
    V = { layers: S.lastLayers, mesh, nx: c.nx, ny: c.ny, z1: c.b.z1, prim: c.prim, ult: c.ult, zNivel: c.zNivel, nNiv: c.zNivel.length - 1, nivel: -1 };
    applyCapa();
    log(`Vista previa del desbaste: bloque de ${c.nx} × ${c.ny} puntos, ${V.nNiv} niveles (${((performance.now() - t0) / 1000).toFixed(1)} s${c.cpp ? ', C++' : ''}). El deslizador de capas recorre el desbaste.`, 'ok');
}
// la pieza impresa vuelve a verse según el deslizador
function applyVis() { const sl = __psById('layerSlider'); if (sl && PS.applyLayerVisibility) PS.applyLayerVisibility(parseInt(sl.value) || 0); }

// el deslizador, el teclado y la línea de tiempo pasan todos por applyLayerVisibility, que reescribe #layerInfo
const info = __psById('layerInfo');
if (info) new MutationObserver(() => { if (V) applyCapa(); }).observe(info, { childList: true, characterData: true, subtree: true });
const maq = __psById('maquina');
if (maq) maq.addEventListener('change', () => { if (S.lastLayers) psVistaDesbaste(); });

Object.assign(PS, { psVistaDesbaste });
})();
