// desbaste.cpp — Desbaste de la SD-M5 (5 ejes) en C++: módulo «pms_desbaste».
// Mismo S-code que cinematica/fresado.js (PROCESS MILL, STOCK_*, TOOL_DIAM, LAYER / RAPID / CUT con «X Y H»),
// pero con Clipper2 en C++ (el Clipper2-ts del navegador se cuelga con lazos degenerados de STL reales).
// Además deja calculado el bloque para la vista previa: por celda, el primer y el último nivel que la fresa toca
// (la altura tras el nivel L es la del último nivel ≤ L que la tocó). El slicer solo lo pinta.
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "clipper2/clipper.h"
#include <algorithm>
#include <array>
#include <cstdint>
#define _USE_MATH_DEFINES
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace py = pybind11;
using namespace Clipper2Lib;

static const double ESC = 1000.0;   // 1 unidad = 1 µm

static inline double area_mm2(const Path64& p) { return std::fabs(Area(p)) / (ESC * ESC); }

// quita lazos sin área (los que cuelgan a Clipper2-ts) y simplifica a eps mm
static Paths64 limpiar(const Paths64& a, double eps_mm, double area_min) {
    Paths64 s = SimplifyPaths(a, eps_mm * ESC, true), out;
    out.reserve(s.size());
    for (auto& p : s) if (p.size() > 2 && area_mm2(p) > area_min) out.push_back(std::move(p));
    return out;
}
static Paths64 crecer(const Paths64& a, double d_mm, double tol_mm = 0.01) {
    if (a.empty() || d_mm == 0) return a;
    return InflatePaths(a, d_mm * ESC, JoinType::Round, EndType::Polygon, 2.0, tol_mm * ESC);
}

struct Fmt {
    std::string s;
    char b[96];
    void linea(const char* t) { s += t; s += '\n'; }
    void xy(double x, double y) { int n = std::snprintf(b, sizeof b, "  X%.3f Y%.3f\n", x, y); s.append(b, n); }
    void xyh(double x, double y, double h) { int n = std::snprintf(b, sizeof b, "  X%.3f Y%.3f H%.3f\n", x, y, h); s.append(b, n); }
};

// z[c]: altura de cada capa; nlazos[c]: lazos de la capa; npts[l]: puntos de cada lazo; xy: x0 y0 x1 y1 ... en mm
py::dict fresado(const std::vector<double>& z, const std::vector<int>& nlazos, const std::vector<int>& npts,
                 const std::vector<double>& xy, double layerH, py::dict opts) {
    auto op = [&](const char* k, double d) { return opts.contains(k) && !opts[k].is_none() ? opts[k].cast<double>() : d; };
    const double D = op("herramienta", 6), r = D / 2, ae = op("ae", D * 0.45), sobre = op("sobre", 0.3);
    const double margen = op("margen", 0), techo = op("techo", 0), seguro = op("seguro", 5), apPedido = op("ap", 1);
    const double fCorte = op("fCorte", 20), fViaje = op("fViaje", 80), maxCeldas = op("celdas", 60000);
    if (z.size() != nlazos.size()) throw std::invalid_argument("z y nlazos no coinciden");

    // secciones (EvenOdd: los huecos vienen como lazos aparte)
    struct Sec { double z; Paths64 p; };
    std::vector<Sec> secs;
    double x0 = 1e300, x1 = -1e300, y0 = 1e300, y1 = -1e300, zTop = 0;
    size_t li = 0, pi = 0;
    for (size_t c = 0; c < z.size(); c++) {
        Paths64 ps;
        for (int k = 0; k < nlazos[c]; k++, li++) {
            if (li >= npts.size()) throw std::invalid_argument("faltan lazos");
            int n = npts[li];
            if ((pi + n) * 2 > xy.size()) throw std::invalid_argument("faltan puntos");
            Path64 p; p.reserve(n);
            for (int j = 0; j < n; j++, pi++) {
                double x = xy[2 * pi], y = xy[2 * pi + 1];
                x0 = std::min(x0, x); x1 = std::max(x1, x); y0 = std::min(y0, y); y1 = std::max(y1, y);
                p.push_back(Point64(std::llround(x * ESC), std::llround(y * ESC)));
            }
            if (p.size() > 2) ps.push_back(std::move(p));
        }
        if (ps.empty()) continue;
        Paths64 u = limpiar(Union(ps, FillRule::EvenOdd), 0.01, 1e-4);
        if (u.empty()) continue;
        secs.push_back({ z[c], std::move(u) });
        zTop = std::max(zTop, z[c] + layerH / 2);
    }
    if (secs.empty()) throw std::invalid_argument("la pieza no tiene secciones que fresar");

    // bloque = caja de la pieza (más margen/techo si se piden; por defecto 0: la contiene justo)
    const double sx0 = x0 - margen, sx1 = x1 + margen, sy0 = y0 - margen, sy1 = y1 + margen, sz0 = 0, sz1 = zTop + techo;
    const int nNiv = std::max(1, (int)std::ceil(sz1 / apPedido - 1e-9));
    const double ap = sz1 / nNiv, zSeg = sz1 + seguro;
    const double g = r - ae / 2;   // el lazo de afuera corta el borde con medio paso lateral
    Paths64 rect = { { Point64(std::llround((sx0 - g) * ESC), std::llround((sy0 - g) * ESC)), Point64(std::llround((sx1 + g) * ESC), std::llround((sy0 - g) * ESC)),
                       Point64(std::llround((sx1 + g) * ESC), std::llround((sy1 + g) * ESC)), Point64(std::llround((sx0 - g) * ESC), std::llround((sy1 + g) * ESC)) } };
    std::sort(secs.begin(), secs.end(), [](const Sec& a, const Sec& b) { return a.z > b.z; });

    // rejilla del bloque para la vista previa
    const double lx = sx1 - sx0, ly = sy1 - sy0;
    const double px = std::max(0.25, std::sqrt(std::max(1e-9, lx * ly) / maxCeldas));
    const int nx = std::max(2, (int)std::ceil(lx / px) + 1), ny = std::max(2, (int)std::ceil(ly / px) + 1);
    std::vector<uint16_t> primero((size_t)nx * ny, 0), ultimo((size_t)nx * ny, 0);   // 0 = no tocada; nivel k → k
    const int rc = (int)std::ceil(r / px);
    const double r2 = r * r;
    auto sello = [&](double x, double y, uint16_t niv) {
        int ci = (int)std::lround((x - sx0) / px), cj = (int)std::lround((y - sy0) / px);
        for (int dj = -rc; dj <= rc; dj++) {
            int j = cj + dj; if (j < 0 || j >= ny) continue;
            double yy = sy0 + j * px - y;
            for (int di = -rc; di <= rc; di++) {
                int k = ci + di; if (k < 0 || k >= nx) continue;
                double xx = sx0 + k * px - x;
                if (xx * xx + yy * yy <= r2) { size_t o = (size_t)j * nx + k; if (!primero[o]) primero[o] = niv; ultimo[o] = niv; }
            }
        }
    };
    auto tramo = [&](double ax, double ay, double bx, double by, uint16_t niv) {
        double L = std::hypot(bx - ax, by - ay); int n = std::max(1, (int)std::ceil(L / px));
        for (int s = 1; s <= n; s++) sello(ax + (bx - ax) * s / n, ay + (by - ay) * s / n, niv);
    };

    Fmt o; o.s.reserve(1 << 22);
    char b[160];
    auto lin = [&](const char* fmt, double v) { std::snprintf(b, sizeof b, fmt, v); o.linea(b); };
    o.linea("; S-code de desbaste para la SD-M5 (fresa plana, de arriba hacia abajo) - pms_desbaste C++");
    o.linea("PROCESS MILL");
    lin("LAYER_STEP %.4f", ap);
    lin("BED_DIAM %.1f", 2 * std::hypot(std::max(-sx0, sx1), std::max(-sy0, sy1)));
    o.linea("KINEMATICS CNC5");
    std::snprintf(b, sizeof b, "TOOL_DIAM %g", D); o.linea(b);
    lin("STOCK_X0 %.3f", sx0); lin("STOCK_X1 %.3f", sx1);
    lin("STOCK_Y0 %.3f", sy0); lin("STOCK_Y1 %.3f", sy1);
    lin("STOCK_Z0 %.3f", sz0); lin("STOCK_Z1 %.3f", sz1);
    std::snprintf(b, sizeof b, "FEED_WALL %g", fCorte); o.linea(b);
    std::snprintf(b, sizeof b, "FEED_TRAVEL %g", fViaje); o.linea(b);

    Paths64 prohibido;
    size_t s = 0;
    long lazos = 0; double largo = 0; bool hayCur = false; double cx = 0, cy = 0;
    std::vector<double> zNiv(nNiv + 1, sz1);
    for (int k = 1; k <= nNiv; k++) {
        const double zk = sz1 - ap * k; zNiv[k] = zk;
        Paths64 nuevas;
        while (s < secs.size() && secs[s].z + layerH / 2 > zk + 1e-6) { nuevas.insert(nuevas.end(), secs[s].p.begin(), secs[s].p.end()); s++; }
        if (!nuevas.empty()) {
            nuevas.insert(nuevas.end(), prohibido.begin(), prohibido.end());
            prohibido = limpiar(Union(nuevas, FillRule::NonZero), 0.01, 1e-4);
        }
        Paths64 zona = Difference(rect, crecer(prohibido, r + sobre), FillRule::NonZero);
        std::vector<Path64> niv;
        for (int it = 0; !zona.empty() && it < 2000; it++) {
            zona = limpiar(zona, 0.005, 0.05);
            for (auto& p : zona) niv.push_back(p);
            zona = crecer(zona, -ae);
        }
        if (niv.empty()) continue;
        std::snprintf(b, sizeof b, "LAYER %d Z%.3f", k - 1, zk); o.linea(b);
        const double hs = zSeg - zk, hb = std::min(hs, ap + 0.5);
        std::vector<char> usado(niv.size(), 0);
        for (size_t m = 0; m < niv.size(); m++) {
            long best = -1; size_t bj = 0; double bd = 1e300;
            for (size_t q = 0; q < niv.size(); q++) {
                if (usado[q]) continue;
                const Path64& p = niv[q];
                size_t paso = std::max<size_t>(1, p.size() >> 4);
                for (size_t j = 0; j < p.size(); j += paso) {
                    double d = hayCur ? std::hypot(p[j].x / ESC - cx, p[j].y / ESC - cy) : 0;
                    if (d < bd) { bd = d; best = (long)q; bj = j; }
                }
            }
            usado[best] = 1;
            const Path64& p = niv[best];
            const double ix = p[bj].x / ESC, iy = p[bj].y / ESC;
            o.linea("RAPID");
            if (hayCur) o.xyh(cx, cy, hs);
            o.xyh(ix, iy, hs);
            o.xyh(ix, iy, hb);
            o.linea("ENDRAPID");
            o.linea("CUT");
            double ax = ix, ay = iy;
            for (size_t j = 0; j <= p.size(); j++) {
                const Point64& q = p[(bj + j) % p.size()];
                double qx = q.x / ESC, qy = q.y / ESC;
                o.xy(qx, qy);
                if (j) { largo += std::hypot(qx - ax, qy - ay); tramo(ax, ay, qx, qy, (uint16_t)k); }
                else sello(qx, qy, (uint16_t)k);
                ax = qx; ay = qy;
            }
            o.linea("ENDCUT");
            o.linea("RAPID");
            o.xyh(ix, iy, hs);
            o.linea("ENDRAPID");
            cx = ix; cy = iy; hayCur = true; lazos++;
        }
        o.linea("ENDLAYER");
    }

    py::dict bloque; bloque["x0"] = sx0; bloque["x1"] = sx1; bloque["y0"] = sy0; bloque["y1"] = sy1; bloque["z0"] = sz0; bloque["z1"] = sz1;
    py::dict stats; stats["bloque"] = bloque; stats["niveles"] = nNiv; stats["ap"] = ap; stats["lazos"] = lazos; stats["largo"] = largo; stats["herramienta"] = D;
    py::dict malla; malla["x0"] = sx0; malla["y0"] = sy0; malla["x1"] = sx1; malla["y1"] = sy1; malla["px"] = px; malla["nx"] = nx; malla["ny"] = ny; malla["z0"] = sz0; malla["z1"] = sz1;
    malla["zNivel"] = zNiv;
    malla["primero"] = py::bytes(reinterpret_cast<const char*>(primero.data()), primero.size() * 2);
    malla["ultimo"] = py::bytes(reinterpret_cast<const char*>(ultimo.data()), ultimo.size() * 2);
    py::dict res; res["scode"] = py::bytes(o.s); res["stats"] = stats; res["malla"] = malla;
    return res;
}

// ══ fresado5: desbaste de 5 ejes (3+2) de la SD-M5 ═══════════════════════════════════════════════════════════════
// Parte de la malla de la pieza (no de las capas): la pieza se desbasta desde arriba y luego desde los lados inclinando
// la cuna A y girando la mesa C, así se llega bajo los voladizos. Cada orientación es un desbaste por niveles a lo largo
// del eje de la herramienta. El material que queda se lleva en vóxeles y en cada punto se comprueba la herramienta
// entera (filo, mango, portaherramientas y nariz del husillo) contra la pieza, el material que queda y la mesa:
// donde algo chocaría, ese tramo no se hace. La fresa solo corta con el filo y nunca entra en la pieza (+ sobrematerial).
// Marco de cada orientación = FRAME del S-code (expandir.js): M = Rz(B)·Ry(A)·Rz(-B), columnas u, v, n (n = eje de la
// herramienta, de la pieza hacia el husillo). En la máquina: cuna A = A, mesa C = 90 - B (driver cnc5_ac).
namespace f5 {

struct V3 { double x, y, z; };
static inline double dot(const V3& a, const V3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }

struct Marco { double A, B; V3 u, v, n; };
static Marco marco(double A, double B) {
    const double d = M_PI / 180, a = A * d, b = B * d, ca = std::cos(a), sa = std::sin(a), cb = std::cos(b), sb = std::sin(b);
    Marco m; m.A = A; m.B = B;
    m.u = { cb * cb * ca + sb * sb, sb * cb * ca - sb * cb, -sa * cb };
    m.v = { cb * sb * ca - cb * sb, sb * sb * ca + cb * cb, -sa * sb };
    m.n = { cb * sa, sb * sa, ca };
    return m;
}

// material en vóxeles: 0xFFFF = pieza, 0 = material sin quitar, k = quitado en la capa k del S-code
struct Rejilla {
    double x0, y0, z0, v; int nx, ny, nz;
    std::vector<uint16_t> q;
    size_t idx(int i, int j, int k) const { return ((size_t)k * ny + j) * nx + i; }
    // -1 fuera, 0 aire, 1 material, 2 pieza
    int en(double x, double y, double z) const {
        int i = (int)std::floor((x - x0) / v), j = (int)std::floor((y - y0) / v), k = (int)std::floor((z - z0) / v);
        if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) return -1;
        uint16_t c = q[idx(i, j, k)];
        return c == 0xFFFF ? 2 : c == 0 ? 1 : 0;
    }
};

// voxeliza la pieza por columnas (paridad de cruces a lo largo de z)
static void voxelizar(Rejilla& G, const float* t, size_t ntri) {
    std::vector<std::vector<float>> col((size_t)G.nx * G.ny);
    for (size_t f = 0; f < ntri; f++) {
        const float* p = t + 9 * f;
        double ax = p[0], ay = p[1], az = p[2], bx = p[3], by = p[4], bz = p[5], cx = p[6], cy = p[7], cz = p[8];
        double den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy);
        if (std::fabs(den) < 1e-12) continue;
        int i0 = std::max(0, (int)std::floor((std::min({ ax, bx, cx }) - G.x0) / G.v - 0.5)), i1 = std::min(G.nx - 1, (int)std::ceil((std::max({ ax, bx, cx }) - G.x0) / G.v - 0.5));
        int j0 = std::max(0, (int)std::floor((std::min({ ay, by, cy }) - G.y0) / G.v - 0.5)), j1 = std::min(G.ny - 1, (int)std::ceil((std::max({ ay, by, cy }) - G.y0) / G.v - 0.5));
        for (int j = j0; j <= j1; j++) for (int i = i0; i <= i1; i++) {
            // centro de la columna, corrido un pelo para no caer justo en una arista compartida
            double x = G.x0 + (i + 0.5) * G.v + 1.3e-7, y = G.y0 + (j + 0.5) * G.v + 2.9e-7;
            double l1 = ((by - cy) * (x - cx) + (cx - bx) * (y - cy)) / den, l2 = ((cy - ay) * (x - cx) + (ax - cx) * (y - cy)) / den, l3 = 1 - l1 - l2;
            if (l1 < 0 || l2 < 0 || l3 < 0) continue;
            col[(size_t)j * G.nx + i].push_back((float)(l1 * az + l2 * bz + l3 * cz));
        }
    }
    for (int j = 0; j < G.ny; j++) for (int i = 0; i < G.nx; i++) {
        auto& c = col[(size_t)j * G.nx + i];
        if (c.size() < 2) continue;
        std::sort(c.begin(), c.end());
        for (size_t m = 0; m + 1 < c.size(); m += 2) {
            int k0 = std::max(0, (int)std::ceil((c[m] - G.z0) / G.v - 0.5)), k1 = std::min(G.nz - 1, (int)std::floor((c[m + 1] - G.z0) / G.v - 0.5));
            for (int k = k0; k <= k1; k++) G.q[G.idx(i, j, k)] = 0xFFFF;
        }
    }
}

// herramienta: tramos de cilindro a lo largo del eje desde la punta (s = 0)
struct Herr { double r, Lf, Ls, Rh, LT, Rn, Ln; };

// puntos de muestra en coordenadas de la herramienta (a, b, s)
struct Muestras { std::vector<V3> filo, filoLleno, filoPieza, cuerpo; std::vector<double> sCuerpo; };
static void disco(std::vector<V3>& out, double R0, double R1, double s, double paso) {
    // corona entre R0 y R1 (R0 = 0: disco lleno) con puntos cada «paso», más el borde exacto
    if (R0 <= 0) out.push_back({ 0, 0, s });
    for (double R = R1; R > R0 + 1e-9; R -= paso) {
        int n = std::max(6, (int)std::ceil(2 * M_PI * R / paso));
        for (int k = 0; k < n; k++) out.push_back({ R * std::cos(2 * M_PI * k / n), R * std::sin(2 * M_PI * k / n), s });
    }
}
static void anilloUno(std::vector<V3>& out, double R, double s, double paso) {
    if (R <= 1e-9) return;
    int n = std::max(6, (int)std::ceil(2 * M_PI * R / paso));
    for (int k = 0; k < n; k++) out.push_back({ R * std::cos(2 * M_PI * k / n), R * std::sin(2 * M_PI * k / n), s });
}
static void anillo(std::vector<V3>& out, double R, double s0, double s1, double paso) {
    int n = std::max(8, (int)std::ceil(2 * M_PI * R / paso)), m = std::max(1, (int)std::ceil((s1 - s0) / paso));
    for (int j = 0; j <= m; j++) for (int k = 0; k < n; k++) out.push_back({ R * std::cos(2 * M_PI * k / n), R * std::sin(2 * M_PI * k / n), s0 + (s1 - s0) * j / m });
}
static Muestras muestras(const Herr& H, double v, double sobre, double hol) {
    Muestras M;
    const int ns = std::max(1, (int)std::ceil(H.Lf / v));
    // filo lleno para tallar; para mirar bastan dos anillos y el eje (corta antes en cuanto encuentra algo)
    for (int j = 0; j <= ns; j++) {
        const double s = H.Lf * j / ns;
        disco(M.filoLleno, 0, H.r, s, v);
        M.filo.push_back({ 0, 0, s }); anilloUno(M.filo, H.r, s, v); anilloUno(M.filo, H.r / 2, s, v);
    }
    // la pieza se mira con la fresa más su sobrematerial menos el error del vóxel (no da falsos choques)
    const double rp = H.r + sobre - 1.75 * v;   // el vóxel y el redondeo de la muestra
    for (int j = 0; j <= ns; j++) {
        const double s = H.Lf * j / ns;
        M.filoPieza.push_back({ 0, 0, s });
        if (rp > 0) { anilloUno(M.filoPieza, rp, s, v); anilloUno(M.filoPieza, rp / 2, s, v); }
    }
    // mango (lleno), portaherramientas y nariz del husillo (cáscara + tapa de abajo), con holgura «hol»
    const double p2 = std::max(1.0, 1.5 * v);
    for (double s = H.Lf; s <= H.Ls + 1e-9; s += v) { size_t a = M.cuerpo.size(); disco(M.cuerpo, 0, H.r + 0.2, s, v); for (size_t k = a; k < M.cuerpo.size(); k++) M.sCuerpo.push_back(s); }
    { size_t a = M.cuerpo.size(); disco(M.cuerpo, 0, H.Rh + hol, H.Ls, p2); anillo(M.cuerpo, H.Rh + hol, H.Ls, H.LT, p2); for (size_t k = a; k < M.cuerpo.size(); k++) M.sCuerpo.push_back(M.cuerpo[k].z); }
    { size_t a = M.cuerpo.size(); disco(M.cuerpo, H.Rh, H.Rn + hol, H.LT, 2 * p2); anillo(M.cuerpo, H.Rn + hol, H.LT, H.LT + H.Ln, 2 * p2); for (size_t k = a; k < M.cuerpo.size(); k++) M.sCuerpo.push_back(M.cuerpo[k].z); }
    // los del cuerpo ordenados por altura: así se corta la búsqueda cuando ya están por encima de todo el material
    std::vector<size_t> o(M.cuerpo.size()); for (size_t k = 0; k < o.size(); k++) o[k] = k;
    std::sort(o.begin(), o.end(), [&](size_t a, size_t b) { return M.sCuerpo[a] < M.sCuerpo[b]; });
    std::vector<V3> c2; std::vector<double> s2; for (size_t k : o) { c2.push_back(M.cuerpo[k]); s2.push_back(M.sCuerpo[k]); }
    M.cuerpo.swap(c2); M.sCuerpo.swap(s2);
    return M;
}
static std::vector<V3> aPieza(const std::vector<V3>& a, const Marco& F) {
    std::vector<V3> o; o.reserve(a.size());
    for (auto& p : a) o.push_back({ F.u.x * p.x + F.v.x * p.y + F.n.x * p.z, F.u.y * p.x + F.v.y * p.y + F.n.y * p.z, F.u.z * p.x + F.v.z * p.y + F.n.z * p.z });
    return o;
}

// polígono convexo recortado por el semiplano a·x + b·y >= c
static std::vector<std::array<double, 2>> semiplano(const std::vector<std::array<double, 2>>& P, double a, double b, double c) {
    std::vector<std::array<double, 2>> o;
    for (size_t k = 0; k < P.size(); k++) {
        auto& p = P[k]; auto& q = P[(k + 1) % P.size()];
        double fp = a * p[0] + b * p[1] - c, fq = a * q[0] + b * q[1] - c;
        if (fp >= 0) o.push_back(p);
        if ((fp >= 0) != (fq >= 0)) { double t = fp / (fp - fq); o.push_back({ p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t }); }
    }
    return o;
}
static std::vector<std::array<double, 2>> casco(std::vector<std::array<double, 2>> P) {
    std::sort(P.begin(), P.end());
    if (P.size() < 3) return P;
    std::vector<std::array<double, 2>> H(2 * P.size());
    size_t k = 0;
    auto cr = [](const std::array<double, 2>& o, const std::array<double, 2>& a, const std::array<double, 2>& b) { return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]); };
    for (size_t i = 0; i < P.size(); i++) { while (k >= 2 && cr(H[k - 2], H[k - 1], P[i]) <= 0) k--; H[k++] = P[i]; }
    for (size_t i = P.size() - 1, t = k + 1; i > 0; i--) { while (k >= t && cr(H[k - 2], H[k - 1], P[i - 1]) <= 0) k--; H[k++] = P[i - 1]; }
    H.resize(k - 1);
    return H;
}
static Path64 aPath(const std::vector<std::array<double, 2>>& P) {
    Path64 o; for (auto& p : P) o.push_back(Point64(std::llround(p[0] * ESC), std::llround(p[1] * ESC)));
    return o;
}

} // namespace f5

// tris: bytes float32 (9 por triángulo, mm, pieza apoyada en z = 0 o arriba)
py::dict fresado5(py::bytes trisB, py::dict opts) {
    using namespace f5;
    auto op = [&](const char* k, double d) { return opts.contains(k) && !opts[k].is_none() ? opts[k].cast<double>() : d; };
    const std::string tb = trisB;
    if (tb.size() < 36 || tb.size() % 36) throw std::invalid_argument("la malla de la pieza viene vacía o cortada");
    size_t nt = tb.size() / 36;

    Herr H;
    const double D = op("herramienta", 6);
    H.r = D / 2; H.Lf = op("largoFilo", 3 * D); H.Ls = std::max(H.Lf, op("voladizo", 40));
    H.Rh = op("portaDiam", 35) / 2; H.LT = std::max(H.Ls + 1, op("largoHerramienta", 120));
    H.Rn = op("narizDiam", 80) / 2; H.Ln = op("narizLargo", 80);
    const double ae = op("ae", D * 0.45), sobre = op("sobre", 0.3), apPedido = op("ap", 1), seguro = op("seguro", 5);
    const double margen = op("margen", 0), techo = op("techo", 0), zMin = op("zMin", 0), hol = op("holgura", 1);
    const double fCorte = op("fCorte", 20), fViaje = op("fViaje", 80), maxVox = op("voxeles", 1.5e6), aireMax = op("aire", 40);
    const double inclinacion = std::min(90.0, std::max(0.0, op("inclinacion", 75)));
    // la SD-M5 (marco de trabajo = centro de la cara de la mesa, eje A en esa cara): el bloque va sobre el plato de
    // 3 garras; mesa Ø400, plato Ø170 × 66; brazos de la cuna |x| 210..290 hasta 110 mm del eje A; apoyos |x| 300..380
    // hasta 185 mm; recorridos X ±250, Y ±230, Z -150..300 (punta, en la máquina)
    const double zPieza = op("zPieza", 66), mesaR = op("mesaR", 200), platoR = op("platoR", 85), platoAlto = op("platoAlto", 66);
    // sujeción: el bloque lleva «agarre» mm de material debajo de la pieza; 4 garras (una por cara del bloque, giran con C)
    // lo aprietan: grueso radial 22, ancho 26, desde el plato hasta el tope del agarre (no suben más: la pieza queda libre)
    const double agarre = std::max(0.0, op("agarre", 12)), garraGrueso = op("garraGrueso", 22), garraAncho = op("garraAncho", 26);
    const double cunaX0 = op("cunaX0", 210), cunaX1 = op("cunaX1", 290), cunaR = op("cunaR", 110);
    const double apoyoX0 = op("apoyoX0", 300), apoyoX1 = op("apoyoX1", 380), apoyoR = op("apoyoR", 185);
    const double limX = op("limX", 250), limY = op("limY", 230), limZ0 = op("limZ0", -150), limZ1 = op("limZ1", 300);
    (void)mesaR;
    const bool lados = op("lados", 1) != 0;
    // el cálculo largo va sin el candado de Python (PMS sigue respondiendo); se recupera al armar el resultado
    auto sinGil = std::make_unique<py::gil_scoped_release>();
    // todo en el marco de trabajo de Machin: la pieza sube zPieza (apoyada en el plato)
    std::vector<float> Tv(nt * 9);
    std::memcpy(Tv.data(), tb.data(), tb.size());
    double subida = 0;
    { float zm = 1e30f; for (size_t k = 0; k < 3 * nt; k++) zm = std::min(zm, Tv[3 * k + 2]); subida = zPieza + agarre - zm; for (size_t k = 0; k < 3 * nt; k++) Tv[3 * k + 2] += (float)subida; }
    // y centrada en X/Y sobre el eje del plato (el slicer la puede tener en cualquier lugar de su cama)
    double corrX = 0, corrY = 0;
    { double x0 = 1e300, x1 = -1e300, y0 = 1e300, y1 = -1e300;
      for (size_t k = 0; k < 3 * nt; k++) { x0 = std::min(x0, (double)Tv[3 * k]); x1 = std::max(x1, (double)Tv[3 * k]); y0 = std::min(y0, (double)Tv[3 * k + 1]); y1 = std::max(y1, (double)Tv[3 * k + 1]); }
      corrX = -(x0 + x1) / 2; corrY = -(y0 + y1) / 2;
      for (size_t k = 0; k < 3 * nt; k++) { Tv[3 * k] += (float)corrX; Tv[3 * k + 1] += (float)corrY; } }

    // caja de la pieza = bloque (+ el agarre debajo)
    double bx0 = 1e300, bx1 = -1e300, by0 = 1e300, by1 = -1e300, bz0 = 1e300, bz1 = -1e300;
    for (size_t k = 0; k < 3 * nt; k++) { double x = Tv[3 * k], y = Tv[3 * k + 1], z = Tv[3 * k + 2]; bx0 = std::min(bx0, x); bx1 = std::max(bx1, x); by0 = std::min(by0, y); by1 = std::max(by1, y); bz0 = std::min(bz0, z); bz1 = std::max(bz1, z); }
    const double sx0 = bx0 - margen, sx1 = bx1 + margen, sy0 = by0 - margen, sy1 = by1 + margen, sz0 = bz0 - agarre, sz1 = bz1 + techo;
    const double garraTope = bz0;   // las garras aprietan el agarre, hasta donde empieza la pieza
    // el agarre se trata como pieza (no se toca): se suma a la malla como una caja cerrada debajo de ella
    if (agarre > 0) {
        const float X0 = (float)sx0, X1 = (float)sx1, Y0 = (float)sy0, Y1 = (float)sy1, Z0 = (float)sz0, Z1 = (float)bz0;
        const float v[8][3] = { { X0, Y0, Z0 }, { X1, Y0, Z0 }, { X1, Y1, Z0 }, { X0, Y1, Z0 }, { X0, Y0, Z1 }, { X1, Y0, Z1 }, { X1, Y1, Z1 }, { X0, Y1, Z1 } };
        const int f[12][3] = { { 0, 2, 1 }, { 0, 3, 2 }, { 4, 5, 6 }, { 4, 6, 7 }, { 0, 1, 5 }, { 0, 5, 4 }, { 1, 2, 6 }, { 1, 6, 5 }, { 2, 3, 7 }, { 2, 7, 6 }, { 3, 0, 4 }, { 3, 4, 7 } };
        for (auto& t : f) for (int c = 0; c < 3; c++) for (int e = 0; e < 3; e++) Tv.push_back(v[t[c]][e]);
        nt += 12;
    }
    const float* T = Tv.data();
    // ¿cabe en la máquina? (punta: Z hasta limZ1 sobre la cara de la mesa, X/Y ±lim)
    {
        char m[400];
        const double ax = bx1 - bx0, ay = by1 - by0, az = bz1 - bz0;
        if (sz1 + seguro > limZ1)
            { std::snprintf(m, sizeof m, "la pieza no cabe en la SD-M5: mide %.0f x %.0f x %.0f mm y sobre el plato llega a %.0f mm, pero el eje Z alcanza %.0f mm. Escálala a menos de %.0f mm de alto.", ax, ay, az, sz1, limZ1, limZ1 - zPieza - agarre - seguro); throw std::invalid_argument(m); }
        if (std::max(-sx0, sx1) + H.Rn > limX || std::max(-sy0, sy1) + H.Rn > limY)
            { std::snprintf(m, sizeof m, "la pieza no cabe en la SD-M5: mide %.0f x %.0f x %.0f mm y el recorrido es X ±%.0f, Y ±%.0f mm.", ax, ay, az, limX, limY); throw std::invalid_argument(m); }
    }

    Rejilla G;
    G.v = std::max(0.4, std::cbrt((sx1 - sx0) * (sy1 - sy0) * (sz1 - sz0) / maxVox));
    G.x0 = sx0; G.y0 = sy0; G.z0 = sz0;
    G.nx = std::max(1, (int)std::ceil((sx1 - sx0) / G.v)); G.ny = std::max(1, (int)std::ceil((sy1 - sy0) / G.v)); G.nz = std::max(1, (int)std::ceil((sz1 - sz0) / G.v));
    G.q.assign((size_t)G.nx * G.ny * G.nz, 0);
    voxelizar(G, T, nt);
    size_t vMat0 = 0; for (auto c : G.q) if (c == 0) vMat0++;

    const Muestras Ms = muestras(H, G.v, sobre, hol + G.v);   // + 1 vóxel: las muestras se redondean al vóxel
    V3 esq[8]; for (int k = 0; k < 8; k++) esq[k] = { k & 1 ? sx1 : sx0, k & 2 ? sy1 : sy0, k & 4 ? sz1 : sz0 };
    double Rbloque = 0; for (auto& e : esq) Rbloque = std::max(Rbloque, std::sqrt(dot(e, e)));

    // orientaciones: arriba y, si se piden, los cuatro lados (en ese orden, de 90° en 90°)
    std::vector<std::array<double, 2>> ors = { { 0, 0 } };
    if (lados && inclinacion > 0) for (double b : { 270.0, 0.0, 90.0, 180.0 }) ors.push_back({ inclinacion, b });

    Fmt o; o.s.reserve(1 << 22);
    char b[200];
    o.linea("; S-code de desbaste de 5 ejes para la SD-M5 (3+2: desde arriba y desde los lados con A/C) - pms_desbaste C++");
    o.linea("; cada nivel lleva FRAME: A = inclinación del eje de la herramienta, B = acimut; en la máquina cuna A = A, mesa C = 90 - B");
    o.linea("PROCESS MILL");
    o.linea("MILL_AXES 5");
    std::snprintf(b, sizeof b, "LAYER_STEP %.4f", apPedido); o.linea(b);
    std::snprintf(b, sizeof b, "BED_DIAM %.1f", 2 * std::hypot(std::max(-sx0, sx1), std::max(-sy0, sy1))); o.linea(b);
    o.linea("KINEMATICS CNC5");
    std::snprintf(b, sizeof b, "TOOL_DIAM %g", D); o.linea(b);
    std::snprintf(b, sizeof b, "TOOL_FLUTE %g", H.Lf); o.linea(b);
    std::snprintf(b, sizeof b, "TOOL_STICKOUT %g", H.Ls); o.linea(b);
    std::snprintf(b, sizeof b, "HOLDER_DIAM %g", 2 * H.Rh); o.linea(b);
    std::snprintf(b, sizeof b, "TOOL_LENGTH %g", H.LT); o.linea(b);
    std::snprintf(b, sizeof b, "STOCK_X0 %.3f", sx0); o.linea(b); std::snprintf(b, sizeof b, "STOCK_X1 %.3f", sx1); o.linea(b);
    std::snprintf(b, sizeof b, "STOCK_Y0 %.3f", sy0); o.linea(b); std::snprintf(b, sizeof b, "STOCK_Y1 %.3f", sy1); o.linea(b);
    std::snprintf(b, sizeof b, "STOCK_Z0 %.3f", sz0); o.linea(b); std::snprintf(b, sizeof b, "STOCK_Z1 %.3f", sz1); o.linea(b);
    std::snprintf(b, sizeof b, "FEED_WALL %g", fCorte); o.linea(b);
    std::snprintf(b, sizeof b, "FEED_TRAVEL %g", fViaje); o.linea(b);
    // sujeción (para dibujarla en Machin): agarre debajo de la pieza y 4 garras que lo aprietan
    std::snprintf(b, sizeof b, "GRIP %g", agarre); o.linea(b);
    std::snprintf(b, sizeof b, "JAW_THICK %g", garraGrueso); o.linea(b);
    std::snprintf(b, sizeof b, "JAW_WIDTH %g", garraAncho); o.linea(b);
    std::snprintf(b, sizeof b, "JAW_Z0 %g", platoAlto - 6); o.linea(b);

    // estacionamiento entre orientaciones: punta quieta en la máquina, frente a la mesa y por encima del bloque;
    // sólo giran A y C (en pasos de 30° como mucho)
    // parque dentro de los recorridos: arriba (Z casi al tope) y hacia adelante en Y lo justo para que el bloque gire
    // sin tocar la nariz del husillo (radio del bloque + 20 mm desde el eje A)
    const double Hfar = limZ1 - 5;
    const double yOff = std::min(limY - 5, std::max(H.Rn + 25, H.Rn + std::sqrt(std::max(0.0, (Rbloque + 20) * (Rbloque + 20) - Hfar * Hfar))));
    auto parque = [&](const Marco& F) {   // punto de la máquina (0, -yOff, Hfar) en el marco de la pieza
        const double d = M_PI / 180, A = F.A * d, C = (90 - F.B) * d;
        const double y1 = -yOff * std::cos(-A) - Hfar * std::sin(-A), z1 = -yOff * std::sin(-A) + Hfar * std::cos(-A);
        return V3{ -y1 * std::sin(-C), y1 * std::cos(-C), z1 };
    };
    int capa = 0;
    auto capaFrame = [&](double h, const Marco& F) {
        std::snprintf(b, sizeof b, "LAYER %d Z%.3f", capa, h); o.linea(b);
        std::snprintf(b, sizeof b, "FRAME X0 Y0 Z0 A%.4f B%.4f", F.A, F.B); o.linea(b);   // origen fijo: H = altura a lo largo del eje
    };
    auto estacionar = [&](const Marco& F, const std::vector<std::array<double, 3>>& antes = {}) {   // capa de un solo punto: la punta en el parque
        V3 p = parque(F);
        capaFrame(dot(p, F.n), F);
        o.linea("RAPID");
        for (auto& q : antes) o.xyh(q[0], q[1], q[2]);
        o.xyh(dot(p, F.u), dot(p, F.v), dot(p, F.n));
        o.linea("ENDRAPID"); o.linea("ENDLAYER");
        capa++;
    };

    long lazos = 0, saltados = 0, muestrasCorte = 0; double largo = 0;
    std::vector<std::array<double, 3>> resumen;   // A, B, niveles
    double Aant = 0, Bant = 0; bool hayAnt = false;
    for (auto& ab : ors) {
        const Marco F = marco(ab[0], ab[1]);
        const double sT = std::sin(F.A * M_PI / 180), cT = std::cos(F.A * M_PI / 180);
        // material que queda, visto a lo largo de n
        double mMax = -1e300, mMin = 1e300, tMax = -1e300; size_t quedan = 0;
        for (int k = 0; k < G.nz; k++) for (int j = 0; j < G.ny; j++) for (int i = 0; i < G.nx; i++) {
            uint16_t c = G.q[G.idx(i, j, k)];
            if (c != 0 && c != 0xFFFF) continue;
            V3 p{ G.x0 + (i + 0.5) * G.v, G.y0 + (j + 0.5) * G.v, G.z0 + (k + 0.5) * G.v };
            double h = dot(p, F.n);
            tMax = std::max(tMax, h);
            if (c == 0) { mMax = std::max(mMax, h); mMin = std::min(mMin, h); quedan++; }
        }
        if (!quedan) { resumen.push_back({ F.A, F.B, 0 }); continue; }
        // la mesa: todo el conjunto (filo, portaherramientas, husillo) por encima de zMin
        const double zEff = zMin + std::max({ H.r * sT, H.Rh * sT - H.Ls * cT, H.Rn * sT - H.LT * cT }) + 0.5;
        const double hTop = tMax + G.v, hs0 = hTop + std::max(seguro, apPedido + 1);
        const int nNiv = std::max(1, (int)std::ceil((hTop - (mMin - G.v)) / apPedido));
        const double ap = apPedido;

        // bloque visto desde n (casco convexo) + medio paso lateral
        std::vector<std::array<double, 2>> pr; for (auto& e : esq) pr.push_back({ dot(e, F.u), dot(e, F.v) });
        const Paths64 base = crecer(Paths64{ aPath(casco(pr)) }, H.r - ae / 2);

        // sombra de la pieza por encima de cada nivel, en una rejilla 2D (u, v): por celda, la altura más alta de la pieza
        // que cae en ella (rasterizado conservador: la celda entra si su centro está a menos de media diagonal del
        // triángulo, con la altura subida por la pendiente). Sombra del nivel h = celdas con altura >= h, como rectángulos.
        double u0 = 1e300, u1 = -1e300, w0 = 1e300, w1 = -1e300;
        for (auto& q : pr) { u0 = std::min(u0, q[0]); u1 = std::max(u1, q[0]); w0 = std::min(w0, q[1]); w1 = std::max(w1, q[1]); }
        const double cel = std::max(0.25, std::min(0.5, 0.75 * G.v)), mdiag = 0.7072 * cel;
        u0 -= 2 * cel; w0 -= 2 * cel;
        const int nu = (int)std::ceil((u1 - u0) / cel) + 3, nw = (int)std::ceil((w1 - w0) / cel) + 3;
        std::vector<float> hc((size_t)nu * nw, -1e30f);
        for (size_t f = 0; f < nt; f++) {
            const float* p = T + 9 * f; double U[3], W[3], Hh[3];
            for (int c = 0; c < 3; c++) { V3 q{ p[3 * c], p[3 * c + 1], p[3 * c + 2] }; U[c] = dot(q, F.u); W[c] = dot(q, F.v); Hh[c] = dot(q, F.n); }
            const double hmx = std::max({ Hh[0], Hh[1], Hh[2] }), hmn = std::min({ Hh[0], Hh[1], Hh[2] });
            const double den = (U[1] - U[0]) * (W[2] - W[0]) - (U[2] - U[0]) * (W[1] - W[0]);
            double al = 0, be = 0; const bool plano = std::fabs(den) > 1e-9;
            if (plano) { al = ((Hh[1] - Hh[0]) * (W[2] - W[0]) - (Hh[2] - Hh[0]) * (W[1] - W[0])) / den; be = ((U[1] - U[0]) * (Hh[2] - Hh[0]) - (U[2] - U[0]) * (Hh[1] - Hh[0])) / den; }
            const double sube = plano ? std::hypot(al, be) * mdiag : 0;
            const int i0 = std::max(0, (int)std::floor((std::min({ U[0], U[1], U[2] }) - mdiag - u0) / cel)), i1 = std::min(nu - 1, (int)std::ceil((std::max({ U[0], U[1], U[2] }) + mdiag - u0) / cel));
            const int j0 = std::max(0, (int)std::floor((std::min({ W[0], W[1], W[2] }) - mdiag - w0) / cel)), j1 = std::min(nw - 1, (int)std::ceil((std::max({ W[0], W[1], W[2] }) + mdiag - w0) / cel));
            for (int j = j0; j <= j1; j++) for (int i = i0; i <= i1; i++) {
                const double x = u0 + (i + 0.5) * cel, y = w0 + (j + 0.5) * cel;
                // punto del triángulo (2D) más cercano al centro de la celda
                double cxp = x, cyp = y, dmin = 0;
                double s1 = (U[1] - U[0]) * (y - W[0]) - (W[1] - W[0]) * (x - U[0]), s2 = (U[2] - U[1]) * (y - W[1]) - (W[2] - W[1]) * (x - U[1]), s3 = (U[0] - U[2]) * (y - W[2]) - (W[0] - W[2]) * (x - U[2]);
                const bool dentro = plano && ((s1 >= 0 && s2 >= 0 && s3 >= 0) || (s1 <= 0 && s2 <= 0 && s3 <= 0));
                if (!dentro) {
                    dmin = 1e300;
                    for (int e = 0; e < 3; e++) {
                        const double ax = U[e], ay = W[e], bx = U[(e + 1) % 3], by = W[(e + 1) % 3], dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy;
                        double t = L2 > 0 ? ((x - ax) * dx + (y - ay) * dy) / L2 : 0; t = std::min(1.0, std::max(0.0, t));
                        const double px = ax + dx * t, py = ay + dy * t, d = std::hypot(x - px, y - py);
                        if (d < dmin) { dmin = d; cxp = px; cyp = py; }
                    }
                    if (dmin > mdiag) continue;
                }
                double hh = plano ? Hh[0] + al * (cxp - U[0]) + be * (cyp - W[0]) + sube : hmx;
                hh = std::min(hmx, std::max(hmn, hh));
                float& c = hc[(size_t)j * nu + i];
                if (hh > c) c = (float)hh;
            }
        }
        std::vector<Paths64> sombra(nNiv + 1);
        auto sombraEn = [&](double hl) {
            Paths64 rects;
            for (int j = 0; j < nw; j++) {
                int i = 0;
                while (i < nu) {
                    if (hc[(size_t)j * nu + i] < hl) { i++; continue; }
                    int e = i; while (e + 1 < nu && hc[(size_t)j * nu + e + 1] >= hl) e++;
                    const double xa = u0 + i * cel, xb = u0 + (e + 1) * cel, ya = w0 + j * cel, yb = w0 + (j + 1) * cel;
                    rects.push_back(aPath({ { xa, ya }, { xb, ya }, { xb, yb }, { xa, yb } }));
                    i = e + 1;
                }
            }
            return rects.empty() ? Paths64{} : limpiar(Union(rects, FillRule::NonZero), 0.01, 1e-4);
        };
        for (int k = 1; k <= nNiv; k++) sombra[k] = sombraEn(hTop - ap * k);

        // cuerpo de la herramienta y filo en el marco de la pieza
        const std::vector<V3> filo = aPieza(Ms.filo, F), filoL = aPieza(Ms.filoLleno, F), filoP = aPieza(Ms.filoPieza, F), cuerpo = aPieza(Ms.cuerpo, F);
        // 0 aire, 1 corta, 2 choque. Sólo se mira el cuerpo que queda por debajo del material más alto
        const double dA = F.A * M_PI / 180, dC = (90 - F.B) * M_PI / 180, ca = std::cos(dA), sa = std::sin(dA), cc = std::cos(dC), sc = std::sin(dC);
        // garras: cajas pegadas a cada cara del bloque (en el marco de la pieza)
        const double gcx = (sx0 + sx1) / 2, gcy = (sy0 + sy1) / 2, gz0 = platoAlto - 6;
        const double garras[4][4] = { { sx1, sx1 + garraGrueso, gcy - garraAncho / 2, gcy + garraAncho / 2 }, { sx0 - garraGrueso, sx0, gcy - garraAncho / 2, gcy + garraAncho / 2 },
                                      { gcx - garraAncho / 2, gcx + garraAncho / 2, sy1, sy1 + garraGrueso }, { gcx - garraAncho / 2, gcx + garraAncho / 2, sy0 - garraGrueso, sy0 } };
        const double bajo = std::min(0.0, F.n.z * (H.LT + H.Ln)) - H.Rn - hol;   // lo más bajo del conjunto respecto de la punta
        // máquina: recorridos, cuna y apoyos (en la máquina la herramienta es vertical) y mesa + plato (en la pieza)
        auto maquina = [&](const V3& P) {
            const double x1 = P.x * cc - P.y * sc, y1 = P.x * sc + P.y * cc, Y = y1 * ca - P.z * sa, Z = y1 * sa + P.z * ca, X = x1;
            if (std::fabs(X) > limX || std::fabs(Y) > limY || Z < limZ0 || Z > limZ1) return false;
            const double tr[4][3] = { { H.r, 0, H.Ls }, { H.Rh, H.Ls, H.LT }, { H.Rn, H.LT, H.LT + H.Ln }, { H.r, 0, H.Lf } };
            for (auto& t : tr) {
                const double Rr = t[0] + hol, z0 = Z + t[1], z1 = Z + t[2];
                const double dy = std::max(0.0, std::fabs(Y) - Rr), dz = z0 > 0 ? z0 : z1 < 0 ? -z1 : 0, d = std::hypot(dy, dz);
                const double xa = std::fabs(X) - Rr, xb = std::fabs(X) + Rr;
                if (xb > cunaX0 && xa < cunaX1 && d < cunaR) return false;
                if (xb > apoyoX0 && xa < apoyoX1 && d < apoyoR) return false;
            }
            if (P.z + bajo > std::max(platoAlto, garraTope) + hol) return true;
            // mesa, plato y garras: cada tramo de la herramienta como esferas de su radio a lo largo del eje (lo cubren entero)
            for (auto& t : tr) {
                const double Rr = t[0] + hol;
                const int m = std::max(1, (int)std::ceil((t[2] - t[1]) / std::max(1.0, 0.5 * t[0])));
                for (int j = 0; j <= m; j++) {
                    const double sj = t[1] + (t[2] - t[1]) * j / m, x = P.x + F.n.x * sj, y = P.y + F.n.y * sj, z = P.z + F.n.z * sj;
                    if (z - Rr > std::max(platoAlto, garraTope)) continue;
                    if (z - Rr < 0) return false;
                    if (z - Rr < platoAlto && std::hypot(x, y) - Rr < platoR) return false;
                    if (z - Rr < garraTope) for (auto& g : garras) {
                        const double dx = std::max({ g[0] - x, x - g[1], 0.0 }), dy = std::max({ g[2] - y, y - g[3], 0.0 }), dz = std::max({ gz0 - z, z - garraTope, 0.0 });
                        if (dx * dx + dy * dy + dz * dz < Rr * Rr) return false;
                    }
                }
            }
            return true;
        };
        // muestras como saltos enteros de vóxel (sin repetir): mirar = sumar índices
        struct Off { int i, j, k; double s; };
        auto aOff = [&](const std::vector<V3>& L, const std::vector<double>* sv) {
            std::vector<Off> o; o.reserve(L.size());
            std::vector<long long> vistos;
            for (size_t k = 0; k < L.size(); k++) {
                Off f{ (int)std::lround(L[k].x / G.v), (int)std::lround(L[k].y / G.v), (int)std::lround(L[k].z / G.v), sv ? (*sv)[k] : 0 };
                long long key = ((long long)(f.i + 4096) << 26) | ((long long)(f.j + 4096) << 13) | (long long)(f.k + 4096);
                vistos.push_back(key); (void)key;
                o.push_back(f);
            }
            // quitar repetidos conservando el orden (el cuerpo va ordenado por altura)
            std::vector<size_t> idx(o.size()); for (size_t k = 0; k < idx.size(); k++) idx[k] = k;
            std::stable_sort(idx.begin(), idx.end(), [&](size_t a, size_t b) { return vistos[a] < vistos[b]; });
            std::vector<char> fuera(o.size(), 0);
            for (size_t k = 1; k < idx.size(); k++) if (vistos[idx[k]] == vistos[idx[k - 1]]) fuera[idx[k]] = 1;
            std::vector<Off> r; for (size_t k = 0; k < o.size(); k++) if (!fuera[k]) r.push_back(o[k]);
            return r;
        };
        const std::vector<Off> oFiloP = aOff(filoP, nullptr), oFilo = aOff(filo, nullptr), oCuerpo = aOff(cuerpo, &Ms.sCuerpo);
        auto en = [&](int i, int j, int k) -> int {
            if (i < 0 || j < 0 || k < 0 || i >= G.nx || j >= G.ny || k >= G.nz) return -1;
            uint16_t c = G.q[G.idx(i, j, k)];
            return c == 0xFFFF ? 2 : c == 0 ? 1 : 0;
        };
        auto mirar = [&](double lx, double ly, double h, bool filoCorta, bool cuerpoSi = true) {
            V3 P{ F.u.x * lx + F.v.x * ly + F.n.x * h, F.u.y * lx + F.v.y * ly + F.n.y * h, F.u.z * lx + F.v.z * ly + F.n.z * h };
            if (!maquina(P)) return 2;
            const int i0 = (int)std::lround((P.x - G.x0) / G.v - 0.5), j0 = (int)std::lround((P.y - G.y0) / G.v - 0.5), k0 = (int)std::lround((P.z - G.z0) / G.v - 0.5);
            for (auto& d : oFiloP) if (en(i0 + d.i, j0 + d.j, k0 + d.k) == 2) return 2;
            int r = 0;
            for (auto& d : oFilo) if (en(i0 + d.i, j0 + d.j, k0 + d.k) == 1) { r = 1; break; }
            if (r && !filoCorta) return 2;
            if (cuerpoSi) for (auto& d : oCuerpo) {
                if (h + d.s > tMax + 2 * G.v) break;   // más arriba no hay material
                if (en(i0 + d.i, j0 + d.j, k0 + d.k) > 0) return 2;
            }
            return r;
        };
        auto tallar = [&](double lx, double ly, double h) {
            V3 P{ F.u.x * lx + F.v.x * ly + F.n.x * h, F.u.y * lx + F.v.y * ly + F.n.y * h, F.u.z * lx + F.v.z * ly + F.n.z * h };
            for (auto& d : filoL) {
                double x = P.x + d.x, y = P.y + d.y, z = P.z + d.z;
                int i = (int)std::floor((x - G.x0) / G.v), j = (int)std::floor((y - G.y0) / G.v), k = (int)std::floor((z - G.z0) / G.v);
                if (i < 0 || j < 0 || k < 0 || i >= G.nx || j >= G.ny || k >= G.nz) continue;
                uint16_t& c = G.q[G.idx(i, j, k)];
                if (c == 0) c = (uint16_t)std::min(capa, 0xFFFE);
            }
        };

        // cambio de orientación: la punta sube al parque, giran A y C de a poco, y baja en el marco nuevo
        if (hayAnt) {
            Marco Fa = marco(Aant, Bant);
            double Ca = 90 - Bant, Cn = 90 - F.B; if (Aant < 1e-6) Ca = Cn;
            double dC = std::remainder(Cn - Ca, 360.0);
            int pasos = std::max(1, (int)std::ceil(std::max(std::fabs(F.A - Aant), std::fabs(dC)) / 30));
            for (int s = 1; s < pasos; s++) { double t = (double)s / pasos; estacionar(marco(Aant + (F.A - Aant) * t, 90 - (Ca + dC * t))); }
            (void)Fa;
        }
        int nivelesHechos = 0;
        estacionar(F);
        // la punta sale del parque; toda travesía se revisa contra la máquina (garras, plato, cuna, recorridos)
        const V3 pq = parque(F);
        bool hayCur = true; double cx = dot(pq, F.u), cy = dot(pq, F.v), cH = dot(pq, F.n);
        auto local = [&](double x, double y, double hh) { return V3{ F.u.x * x + F.v.x * y + F.n.x * hh, F.u.y * x + F.v.y * y + F.n.y * hh, F.u.z * x + F.v.z * y + F.n.z * hh }; };
        auto tramoOk = [&](const std::array<double, 3>& a, const std::array<double, 3>& c) {
            const int m = std::max(1, (int)std::ceil(std::hypot(c[0] - a[0], c[1] - a[1], c[2] - a[2]) / 2));
            for (int t = 0; t <= m; t++) if (!maquina(local(a[0] + (c[0] - a[0]) * t / m, a[1] + (c[1] - a[1]) * t / m, a[2] + (c[2] - a[2]) * t / m))) return false;
            return true;
        };
        const double Halto = std::max(std::min(Hfar, hs0 + 40), hs0 + 2);
        // de donde está la punta a (x, y, hs): directo, o subiendo a Halto si en el camino algo estorba
        auto ruta = [&](double x, double y, std::vector<std::array<double, 3>>& out) {
            std::array<double, 3> A{ cx, cy, cH }, B{ x, y, hs0 };
            out.clear();
            if (tramoOk(A, B)) { out = { A, B }; return true; }
            std::array<double, 3> a1{ cx, cy, std::max(Halto, cH) }, b1{ x, y, std::max(Halto, cH) };
            if (tramoOk(A, a1) && tramoOk(a1, b1) && tramoOk(b1, B)) { out = { A, a1, b1, B }; return true; }
            return false;
        };
        std::vector<std::array<double, 3>> camino;
        for (int k = 1; k <= nNiv; k++) {
            const double h = hTop - ap * k;
            if (h < mMin - G.v) break;
            // la mesa
            std::vector<std::array<double, 2>> zonaBase;
            if (std::fabs(F.u.z) < 1e-9 && std::fabs(F.v.z) < 1e-9) { if (F.n.z * h < zEff) continue; }
            // forbidden: filo + sobrematerial; portaherramientas y husillo contra la pieza más arriba
            Paths64 prohibido = crecer(sombra[k], H.r + sobre + 0.02, 0.02);
            const int jh = k - (int)std::floor(H.Ls / ap), jn = k - (int)std::floor(H.LT / ap);
            if (jh >= 1 && !sombra[jh].empty()) { Paths64 e = crecer(sombra[jh], H.Rh + hol + 0.1, 0.1); prohibido.insert(prohibido.end(), e.begin(), e.end()); }
            if (jn >= 1 && !sombra[jn].empty()) { Paths64 e = crecer(sombra[jn], H.Rn + hol + 0.1, 0.1); prohibido.insert(prohibido.end(), e.begin(), e.end()); }
            Paths64 libre = base;
            if (!(std::fabs(F.u.z) < 1e-9 && std::fabs(F.v.z) < 1e-9)) {
                // p.z = u.z·x + v.z·y + n.z·h >= zEff (semiplano), sobre una caja grande
                const double L = 1e5;
                std::vector<std::array<double, 2>> caja = { { -L, -L }, { L, -L }, { L, L }, { -L, L } };
                auto sp = semiplano(caja, F.u.z, F.v.z, zEff - F.n.z * h);
                if (sp.size() < 3) continue;
                libre = Intersect(libre, Paths64{ aPath(sp) }, FillRule::NonZero);
            }
            Paths64 zona = prohibido.empty() ? libre : Difference(libre, Union(prohibido, FillRule::NonZero), FillRule::NonZero);
            std::vector<Path64> niv;
            for (int it = 0; !zona.empty() && it < 2000; it++) {
                zona = limpiar(zona, 0.005, 0.05);
                for (auto& p : zona) niv.push_back(p);
                zona = crecer(zona, -ae, 0.05);
            }
            if (niv.empty()) continue;
            const double hs = hs0, hb = std::min(hs0, h + ap + 0.5);   // alturas absolutas a lo largo de n
            const double paso = std::max(0.5, G.v);
            bool abierta = false;
            std::vector<char> usado(niv.size(), 0);
            for (size_t m = 0; m < niv.size(); m++) {
                long best = -1; size_t bj = 0; double bd = 1e300;
                for (size_t q = 0; q < niv.size(); q++) {
                    if (usado[q]) continue;
                    const Path64& p = niv[q];
                    size_t pz = std::max<size_t>(1, p.size() >> 4);
                    for (size_t j = 0; j < p.size(); j += pz) {
                        double d = hayCur ? std::hypot(p[j].x / ESC - cx, p[j].y / ESC - cy) : 0;
                        if (d < bd) { bd = d; best = (long)q; bj = j; }
                    }
                }
                usado[best] = 1;
                const Path64& p = niv[best];
                // lazo cerrado en puntos cada «paso» (los vértices originales se marcan para escribir sólo esos)
                std::vector<std::array<double, 2>> pts; std::vector<char> vert;
                for (size_t j = 0; j <= p.size(); j++) {
                    const Point64& a = p[(bj + j) % p.size()];
                    double ax = a.x / ESC, ay = a.y / ESC;
                    if (j) {
                        double px0 = pts.back()[0], py0 = pts.back()[1], L = std::hypot(ax - px0, ay - py0);
                        int n = std::max(1, (int)std::ceil(L / paso));
                        for (int s = 1; s < n; s++) { pts.push_back({ px0 + (ax - px0) * s / n, py0 + (ay - py0) * s / n }); vert.push_back(0); }
                    }
                    pts.push_back({ ax, ay }); vert.push_back(1);
                }
                std::vector<char> est(pts.size());
                // el cuerpo (con holgura de más de un vóxel) se mira cada 3 puntos y en los extremos
                for (size_t j = 0; j < pts.size(); j++) est[j] = (char)mirar(pts[j][0], pts[j][1], h, true, j % 3 == 0 || j + 1 == pts.size());
                // tramos sin choque; se recortan los extremos al aire y se parten en aires largos
                size_t j = 0;
                while (j < pts.size()) {
                    if (est[j] != 1) { if (est[j] == 2) saltados++; j++; continue; }
                    size_t e = j; double aire = 0; size_t ultCorte = j;
                    while (e + 1 < pts.size() && est[e + 1] != 2) {
                        double dl = std::hypot(pts[e + 1][0] - pts[e][0], pts[e + 1][1] - pts[e][1]);
                        if (est[e + 1] == 0) { aire += dl; if (aire > aireMax) break; } else { aire = 0; ultCorte = e + 1; }
                        e++;
                    }
                    e = ultCorte;
                    // entrada: la bajada desde la altura segura tiene que estar libre (si no, se corre el comienzo)
                    size_t s0 = j; bool ok = false;
                    for (; s0 <= e; s0++) {
                        ok = true;
                        for (double hh = hs; hh > hb - 1e-9 && ok; hh -= std::max(2.0, G.v)) if (mirar(pts[s0][0], pts[s0][1], hh, false)) ok = false;
                        if (ok) break;
                    }
                    // las travesías van a la altura segura: arriba de la entrada y de la salida también tiene que caber la máquina
                    auto alto = [&](size_t q) { return maquina(V3{ F.u.x * pts[q][0] + F.v.x * pts[q][1] + F.n.x * hs, F.u.y * pts[q][0] + F.v.y * pts[q][1] + F.n.y * hs, F.u.z * pts[q][0] + F.v.z * pts[q][1] + F.n.z * hs }); };
                    if (ok && s0 < e && !(alto(s0) && alto(e))) { ok = false; saltados++; }
                    if (ok && s0 < e && !(ruta(pts[s0][0], pts[s0][1], camino) && tramoOk({ pts[e][0], pts[e][1], h }, { pts[e][0], pts[e][1], hs }))) { ok = false; saltados++; }
                    if (ok && s0 < e) {
                        if (!abierta) { capaFrame(h, F); abierta = true; }
                        const double ix = pts[s0][0], iy = pts[s0][1];
                        o.linea("RAPID");
                        for (auto& q : camino) o.xyh(q[0], q[1], q[2]);
                        o.xyh(ix, iy, hb);
                        o.linea("ENDRAPID");
                        o.linea("CUT");
                        for (size_t q = s0; q <= e; q++) {
                            if (q == s0 || q == e || vert[q]) o.xyh(pts[q][0], pts[q][1], h);
                            if (q > s0) largo += std::hypot(pts[q][0] - pts[q - 1][0], pts[q][1] - pts[q - 1][1]);
                            tallar(pts[q][0], pts[q][1], h);
                            muestrasCorte++;
                        }
                        o.linea("ENDCUT");
                        o.linea("RAPID");
                        o.xyh(pts[e][0], pts[e][1], hs);
                        o.linea("ENDRAPID");
                        cx = pts[e][0]; cy = pts[e][1]; cH = hs; hayCur = true; lazos++;
                    }
                    j = e + 1;
                }
            }
            if (abierta) { o.linea("ENDLAYER"); capa++; nivelesHechos++; }
        }
        // sale al parque antes de girar
        if (nivelesHechos) {
            const std::array<double, 3> a{ cx, cy, cH }, a1{ cx, cy, std::max(Halto, cH) }, pp{ dot(pq, F.u), dot(pq, F.v), dot(pq, F.n) };
            if (!(tramoOk(a, a1) && tramoOk(a1, pp))) saltados++;
            estacionar(F, { a1 });
        }
        Aant = F.A; Bant = F.B; hayAnt = true;
        resumen.push_back({ F.A, F.B, (double)nivelesHechos });
    }

    size_t vMat = 0; for (auto c : G.q) if (c == 0) vMat++;
    sinGil.reset();
    py::list lres; for (auto& r : resumen) { py::dict ro; ro["A"] = r[0]; ro["B"] = r[1]; ro["niveles"] = (int)r[2]; lres.append(ro); }
    py::dict bloque; bloque["x0"] = sx0; bloque["x1"] = sx1; bloque["y0"] = sy0; bloque["y1"] = sy1; bloque["z0"] = sz0; bloque["z1"] = sz1;
    py::dict stats;
    stats["bloque"] = bloque; stats["niveles"] = capa; stats["ap"] = apPedido; stats["lazos"] = lazos; stats["largo"] = largo; stats["herramienta"] = D;
    stats["orientaciones"] = lres; stats["choquesEvitados"] = saltados;
    stats["restante"] = vMat0 ? 100.0 * vMat / vMat0 : 0.0; stats["voxel"] = G.v; stats["muestras"] = muestrasCorte; stats["zPieza"] = zPieza; stats["agarre"] = agarre;
    py::dict vox; vox["x0"] = G.x0 - corrX; vox["y0"] = G.y0 - corrY;   // de vuelta al lugar de la pieza en el slicer
    vox["corrX"] = corrX; vox["corrY"] = corrY; vox["z0"] = G.z0; vox["v"] = G.v; vox["nx"] = G.nx; vox["ny"] = G.ny; vox["nz"] = G.nz; vox["niveles"] = capa; vox["zPieza"] = subida; vox["kAgarre"] = (int)std::lround(agarre / G.v);
    vox["q"] = py::bytes(reinterpret_cast<const char*>(G.q.data()), G.q.size() * 2);
    py::dict res; res["scode"] = py::bytes(o.s); res["stats"] = stats; res["vox"] = vox;
    return res;
}

PYBIND11_MODULE(pms_desbaste, m) {
    m.doc() = "Desbaste de la SD-M5: fresado (3 ejes, por capas) y fresado5 (5 ejes 3+2 desde la malla, sin choques)";
    m.def("fresado", &fresado, py::arg("z"), py::arg("nlazos"), py::arg("npts"), py::arg("xy"), py::arg("layerH"), py::arg("opts") = py::dict());
    m.def("fresado5", &fresado5, py::arg("tris"), py::arg("opts") = py::dict());
}
