// Driver cnc5_ac Stonward Dynamic (SD-M5): RTCP de 5 ejes con muñón A (cuna, gira sobre X) y mesa C (gira sobre su eje).
// X, Y, Z del G-code están en el marco de la mesa (origen al centro de su cara, gira con C y bascula con A);
// la herramienta es vertical y sólo se mueve en X, Y, Z de la máquina.
MachinV2.registrarDriver("cnc5_ac", {
  ejes: ["X", "Y", "Z", "A", "C"],
  ik(t, M) {
    const d = Math.PI / 180;
    const X = t.X ?? 0, Y = t.Y ?? 0, Z = t.Z ?? 0, A = t.A ?? 0, C = t.C ?? 0;
    const cc = Math.cos(C * d), sc = Math.sin(C * d), ca = Math.cos(A * d), sa = Math.sin(A * d);
    const x1 = X * cc - Y * sc, y1 = X * sc + Y * cc;              // primero gira la mesa (C)
    const y2 = y1 * ca - Z * sa, z2 = y1 * sa + Z * ca;              // luego bascula la cuna (A) sobre el eje que pasa por la cara de la mesa
    return { ejeX: x1, ejeY: y2, ejeZ: z2, cuna: A, mesaC: C };
  }
});
