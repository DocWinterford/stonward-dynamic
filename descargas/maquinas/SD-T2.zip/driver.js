// Driver torno Stonward Dynamic (SD-T2): X en DIÁMETRO y Z a lo largo del husillo, desde la cara de la pieza.
// El carro X corre sobre la bancada inclinada a 45°, así que el radio va directo a su junta; C es el giro del husillo.
MachinV2.registrarDriver("torno", {
  ejes: ["X", "Z", "C"],
  ik(t, M) {
    const X = t.X ?? 0, Z = t.Z ?? 0, C = t.C ?? 0;
    return { carroZ: Z, carroX: X / 2, husillo: C };
  }
});
