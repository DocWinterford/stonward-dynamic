// Driver brazo6 Stonward Dynamic (SD-R7): X, Y, Z de la boquilla en el marco de la mesa polar (origen al centro de
// la cama, gira con C) -> ángulos de J1..J6 y de la mesa. La herramienta queda siempre vertical y sin girar.
MachinV2.registrarDriver("brazo6", {
  ejes: ["X", "Y", "Z", "C"],
  ik(t, M) {
    const b = M.params.brazo, d = Math.PI / 180;
    const X = t.X ?? 0, Y = t.Y ?? 0, Z = t.Z ?? 0, C = t.C ?? 0;
    const c = Math.cos(C * d), s = Math.sin(C * d);
    const tx = b.mesa[0] + X * c - Y * s, ty = b.mesa[1] + X * s + Y * c, tz = b.mesa[2] + Z;
    const wx = tx - b.tox, wy = ty, wz = tz + b.d6;                 // centro de la muñeca
    const q1 = Math.atan2(wy, wx);
    const r = Math.hypot(wx, wy), h = wz - b.h1;
    let D = (r * r + h * h - b.l2 * b.l2 - b.l3 * b.l3) / (2 * b.l2 * b.l3);
    D = Math.max(-1, Math.min(1, D));
    const g = Math.acos(D);                                         // codo arriba
    const q2 = Math.atan2(r, h) - Math.atan2(b.l3 * Math.sin(g), b.l2 + b.l3 * Math.cos(g));
    const q3 = g - Math.PI / 2;
    return { J1: q1 / d, J2: q2 / d, J3: q3 / d, J4: 0, J5: -(q2 + q3) / d, J6: -q1 / d, mesa: C };
  }
});
