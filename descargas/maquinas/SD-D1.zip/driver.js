// Driver delta Stonward Dynamic (SD-D1): X, Y, Z de la boquilla (origen en el centro de la cama)
// -> altura de los tres carros. Cada carro sube lo que haga falta para que su brazo (largo fijo) llegue al efector.
MachinV2.registrarDriver("delta", {
  ejes: ["X", "Y", "Z"],
  ik(t, M) {
    const d = M.params.delta, L = d.brazo, R = d.radio, h0 = Math.sqrt(L * L - R * R);
    const X = t.X ?? 0, Y = t.Y ?? 0, Z = t.Z ?? 0;
    const q = { efX: X, efY: Y, efector: Z };
    d.torres.forEach((T) => {
      const a = T.ang * Math.PI / 180, dx = R * Math.cos(a) - X, dy = R * Math.sin(a) - Y;
      const h2 = L * L - dx * dx - dy * dy;
      q[T.id] = Z + Math.sqrt(Math.max(0, h2)) - h0;
    });
    return q;
  }
});
